#!/usr/bin/env python3
"""
Script principal para rodar Claude Code SEM API KEY
Usa o CLI local já autenticado
"""

import asyncio
import sys
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from claude_cli_client_fixed import ClaudeCLIClient


async def interactive_mode():
    """Modo interativo para testar o Claude CLI"""
    
    print("\n" + "="*60)
    print("🤖 CLAUDE CODE - MODO SEM API KEY")
    print("   Usando Claude CLI local (já autenticado)")
    print("="*60)
    
    client = ClaudeCLIClient()
    
    # Testar conexão
    print("\n🔍 Verificando conexão...")
    if not await client.test_connection():
        print("❌ Claude CLI não está funcionando")
        print("\nPara configurar:")
        print("1. Instale: npm install -g @anthropic-ai/claude-code")
        print("2. Faça login: claude login")
        return
    
    print("✅ Claude CLI conectado e funcionando!")
    print("\nDigite 'sair' para encerrar")
    print("Comandos especiais:")
    print("  /code <descrição> - Gerar código")
    print("  /analyze - Analisar código")
    print("  /a2a <tarefa> - Executar com A2A")
    print("-" * 60)
    
    while True:
        try:
            prompt = input("\n💬 Você: ").strip()
            
            if prompt.lower() in ['sair', 'exit', 'quit']:
                print("👋 Até logo!")
                break
            
            if not prompt:
                continue
            
            # Comandos especiais
            if prompt.startswith("/code "):
                description = prompt[6:]
                print("\n🤖 Claude (gerando código):")
                response = await client.generate_code(description, "python")
                print(response.content if response.success else f"Erro: {response.error}")
                
            elif prompt == "/analyze":
                print("Cole o código (termine com linha vazia):")
                lines = []
                while True:
                    line = input()
                    if not line:
                        break
                    lines.append(line)
                code = "\n".join(lines)
                
                print("\n🤖 Claude (analisando):")
                response = await client.analyze_code(code, "python")
                print(response.content if response.success else f"Erro: {response.error}")
                
            elif prompt.startswith("/a2a "):
                task = prompt[5:]
                print("\n🤖 Claude (modo A2A):")
                response = await client.execute_with_a2a(task)
                print(response.content if response.success else f"Erro: {response.error}")
                
            else:
                # Query normal
                print("\n🤖 Claude: ", end="", flush=True)
                response = await client.query_simple(prompt)
                
                if response.success:
                    # Simular digitação
                    words = response.content.split()
                    for i, word in enumerate(words):
                        print(word, end=" ", flush=True)
                        if i % 10 == 0:
                            await asyncio.sleep(0.05)
                    print()
                else:
                    print(f"\n❌ Erro: {response.error}")
                    
        except KeyboardInterrupt:
            print("\n\n👋 Interrompido!")
            break
        except Exception as e:
            print(f"\n❌ Erro: {str(e)}")


async def batch_mode(prompts: list):
    """Modo batch para processar múltiplos prompts"""
    
    print("\n🤖 Processando em lote...")
    client = ClaudeCLIClient()
    
    for i, prompt in enumerate(prompts, 1):
        print(f"\n[{i}/{len(prompts)}] Prompt: {prompt[:50]}...")
        response = await client.query_simple(prompt)
        
        if response.success:
            print(f"✅ Resposta: {response.content[:200]}...")
        else:
            print(f"❌ Erro: {response.error}")
        
        await asyncio.sleep(1)  # Evitar sobrecarga


async def demo_mode():
    """Modo demonstração com exemplos"""
    
    print("\n" + "="*60)
    print("🎯 DEMONSTRAÇÃO DO CLAUDE CLI (SEM API KEY)")
    print("="*60)
    
    client = ClaudeCLIClient()
    
    demos = [
        ("🧮 Matemática", "Quanto é 15% de 240?"),
        ("💻 Código", "Crie uma função Python para validar CPF"),
        ("📝 Explicação", "Explique o que é recursão em programação"),
        ("🔍 Análise", "Analise: def fib(n): return n if n <= 1 else fib(n-1) + fib(n-2)"),
        ("🚀 A2A", "Crie um sistema de login com validação")
    ]
    
    for title, prompt in demos:
        print(f"\n{title}")
        print("-" * 40)
        print(f"Prompt: {prompt}")
        
        if "Analise:" in prompt:
            code = prompt.replace("Analise: ", "")
            response = await client.analyze_code(code, "python", "explain")
        elif title == "🚀 A2A":
            response = await client.execute_with_a2a(prompt)
        elif title == "💻 Código":
            response = await client.generate_code(prompt.replace("Crie ", ""), "python")
        else:
            response = await client.query_simple(prompt)
        
        if response.success:
            print(f"Resposta: {response.content[:300]}...")
        else:
            print(f"Erro: {response.error}")
        
        await asyncio.sleep(2)
    
    print("\n✅ Demonstração concluída!")


async def main():
    """Função principal"""
    
    import argparse
    parser = argparse.ArgumentParser(description="Claude Code sem API Key")
    parser.add_argument("mode", nargs="?", default="interactive",
                       choices=["interactive", "demo", "batch"],
                       help="Modo de execução")
    parser.add_argument("--prompts", nargs="+", 
                       help="Prompts para modo batch")
    
    args = parser.parse_args()
    
    if args.mode == "demo":
        await demo_mode()
    elif args.mode == "batch":
        if args.prompts:
            await batch_mode(args.prompts)
        else:
            print("Erro: Forneça prompts com --prompts")
    else:
        await interactive_mode()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n👋 Programa encerrado")
    except Exception as e:
        print(f"❌ Erro fatal: {str(e)}")
        sys.exit(1)