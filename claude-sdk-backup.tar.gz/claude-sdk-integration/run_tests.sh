#!/bin/bash

# Script para executar todos os testes de integração

echo "======================================"
echo "🚀 TESTES DO CLAUDE CODE SDK"
echo "======================================"

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Verificar Python
echo -e "\n${YELLOW}📋 Verificando ambiente...${NC}"
python_version=$(python3 --version 2>&1)
if [ $? -eq 0 ]; then
    echo -e "✅ Python: $python_version"
else
    echo -e "${RED}❌ Python 3 não encontrado${NC}"
    exit 1
fi

# Verificar Node.js
node_version=$(node --version 2>&1)
if [ $? -eq 0 ]; then
    echo -e "✅ Node.js: $node_version"
else
    echo -e "${RED}❌ Node.js não encontrado${NC}"
    echo "Instale Node.js 18+ para continuar"
    exit 1
fi

# Verificar Claude CLI
claude_version=$(claude --version 2>&1)
if [ $? -eq 0 ]; then
    echo -e "✅ Claude CLI: instalado"
else
    echo -e "${YELLOW}⚠️ Claude CLI não encontrado${NC}"
    echo "Instalando Claude CLI..."
    npm install -g @anthropic-ai/claude-code
fi

# Verificar API Key
if [ -z "$ANTHROPIC_API_KEY" ]; then
    echo -e "${RED}❌ ANTHROPIC_API_KEY não configurada${NC}"
    echo "Configure com: export ANTHROPIC_API_KEY='sua-chave-aqui'"
    exit 1
else
    echo -e "✅ API Key configurada"
fi

# Instalar dependências Python
echo -e "\n${YELLOW}📦 Instalando dependências...${NC}"
pip install -q -r requirements.txt
if [ $? -eq 0 ]; then
    echo -e "✅ Dependências instaladas"
else
    echo -e "${RED}❌ Erro ao instalar dependências${NC}"
    exit 1
fi

# Menu de testes
echo -e "\n${YELLOW}🧪 Escolha o teste para executar:${NC}"
echo "1) Teste de conexão básica"
echo "2) Teste do servidor API"
echo "3) Teste do cliente UI"
echo "4) Teste de integração completa"
echo "5) Executar todos os testes"
echo "6) Iniciar servidor API (modo desenvolvimento)"
echo "7) Iniciar cliente interativo"

read -p "Opção: " choice

case $choice in
    1)
        echo -e "\n${YELLOW}🧪 Executando teste de conexão...${NC}"
        python3 tests/test_connection.py
        ;;
    2)
        echo -e "\n${YELLOW}🧪 Executando teste do servidor API...${NC}"
        echo "Iniciando servidor em background..."
        python3 src/api_server_improved.py &
        SERVER_PID=$!
        sleep 3
        python3 tests/test_api_server.py
        kill $SERVER_PID 2>/dev/null
        ;;
    3)
        echo -e "\n${YELLOW}🧪 Executando teste do cliente UI...${NC}"
        python3 tests/test_full_integration.py ui-only
        ;;
    4)
        echo -e "\n${YELLOW}🧪 Executando teste de integração completa...${NC}"
        python3 tests/test_full_integration.py
        ;;
    5)
        echo -e "\n${YELLOW}🧪 Executando todos os testes...${NC}"
        
        # Teste 1: Conexão
        echo -e "\n${YELLOW}[1/3] Teste de conexão${NC}"
        python3 tests/test_connection.py
        test1=$?
        
        # Teste 2: Integração completa
        echo -e "\n${YELLOW}[2/3] Teste de integração${NC}"
        python3 tests/test_full_integration.py
        test2=$?
        
        # Teste 3: Cliente UI
        echo -e "\n${YELLOW}[3/3] Teste do cliente UI${NC}"
        python3 src/ui_client.py
        test3=$?
        
        # Resumo
        echo -e "\n${YELLOW}📊 RESUMO DOS TESTES${NC}"
        if [ $test1 -eq 0 ]; then
            echo -e "   Conexão: ${GREEN}✅ PASSOU${NC}"
        else
            echo -e "   Conexão: ${RED}❌ FALHOU${NC}"
        fi
        
        if [ $test2 -eq 0 ]; then
            echo -e "   Integração: ${GREEN}✅ PASSOU${NC}"
        else
            echo -e "   Integração: ${RED}❌ FALHOU${NC}"
        fi
        
        if [ $test3 -eq 0 ]; then
            echo -e "   Cliente UI: ${GREEN}✅ PASSOU${NC}"
        else
            echo -e "   Cliente UI: ${RED}❌ FALHOU${NC}"
        fi
        
        if [ $test1 -eq 0 ] && [ $test2 -eq 0 ] && [ $test3 -eq 0 ]; then
            echo -e "\n${GREEN}🎉 TODOS OS TESTES PASSARAM!${NC}"
            echo -e "${GREEN}✅ Sua UI está pronta para usar o Claude Code SDK!${NC}"
        else
            echo -e "\n${RED}⚠️ Alguns testes falharam${NC}"
        fi
        ;;
    6)
        echo -e "\n${YELLOW}🚀 Iniciando servidor API...${NC}"
        python3 src/api_server_improved.py
        ;;
    7)
        echo -e "\n${YELLOW}🤖 Iniciando cliente interativo...${NC}"
        python3 src/ui_client.py interactive
        ;;
    *)
        echo -e "${RED}Opção inválida${NC}"
        exit 1
        ;;
esac