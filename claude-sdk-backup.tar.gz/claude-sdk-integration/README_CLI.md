# Claude Code CLI Integration (Sem API Key)

## 🚀 Visão Geral

Esta integração usa o **Claude Code CLI** diretamente, sem necessidade de API key! 
O CLI usa a autenticação local já configurada quando você faz `claude login`.

## ✅ Vantagens

- **Sem API Key**: Usa autenticação local do CLI
- **Mais simples**: Não precisa configurar variáveis de ambiente
- **Mesmas funcionalidades**: Query, análise, geração de código, etc
- **Gratuito**: Usa sua conta Claude já autenticada

## 📦 Instalação

### 1. Instalar Claude CLI

```bash
# Instalar globalmente
npm install -g @anthropic-ai/claude-code

# Verificar instalação
claude --version
```

### 2. Fazer Login

```bash
# Autenticar no Claude
claude login

# Seguir instruções no navegador
```

### 3. Instalar Dependências Python

```bash
# Criar ambiente virtual
python -m venv venv
source venv/bin/activate  # No Windows: venv\Scripts\activate

# Instalar dependências
pip install fastapi uvicorn aiohttp
```

## 🔧 Arquivos Principais

### 1. Cliente CLI (`src/claude_cli_client.py`)

Cliente Python que executa comandos Claude CLI:

```python
from claude_cli_client import ClaudeCLIClient

# Criar cliente (sem API key!)
client = ClaudeCLIClient()

# Query simples
response = await client.query_simple("Explique Python")
print(response.content)

# Gerar código
response = await client.generate_code(
    "função para validar email",
    language="python"
)
print(response.content)

# Streaming
async for line in client.stream_response("Conte até 5"):
    print(line)
```

### 2. API Server (`src/api_server_cli.py`)

Servidor FastAPI que expõe o CLI via REST:

```bash
# Iniciar servidor
python src/api_server_cli.py

# API disponível em http://localhost:8000
# Docs em http://localhost:8000/docs
```

### 3. Testes (`tests/test_cli_client.py`)

```bash
# Executar testes
python tests/test_cli_client.py
```

## 📡 Endpoints da API

### Query Simples
```bash
curl -X POST http://localhost:8000/api/query \
  -H "Content-Type: application/json" \
  -d '{"prompt": "O que é Python?"}'
```

### Análise de Código
```bash
curl -X POST http://localhost:8000/api/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "code": "def hello(): return \"world\"",
    "language": "python",
    "task": "explain"
  }'
```

### Geração de Código
```bash
curl -X POST http://localhost:8000/api/generate \
  -H "Content-Type: application/json" \
  -d '{
    "description": "função fibonacci",
    "language": "python"
  }'
```

### Execução A2A (Simulada)
```bash
curl -X POST http://localhost:8000/api/a2a \
  -H "Content-Type: application/json" \
  -d '{
    "task": "criar API REST",
    "agents": ["developer", "tester", "reviewer"]
  }'
```

### Server-Sent Events (SSE)
```javascript
// JavaScript para consumir SSE
const evtSource = new EventSource('/api/sse');

evtSource.addEventListener('line', (e) => {
    const data = JSON.parse(e.data);
    console.log('Linha:', data.content);
});

evtSource.addEventListener('done', (e) => {
    console.log('Concluído!');
    evtSource.close();
});
```

## 🎯 Exemplo de Uso Completo

```python
# example.py
import asyncio
from claude_cli_client import ClaudeCLIClient

async def main():
    # Criar cliente (sem API key!)
    client = ClaudeCLIClient()
    
    # 1. Testar conexão
    if await client.test_connection():
        print("✅ Claude CLI funcionando!")
    
    # 2. Query simples
    resp = await client.query_simple("Crie uma TODO list em Python")
    print(f"Resposta: {resp.content}")
    
    # 3. Analisar código
    code = """
    def calculate(a, b):
        return a + b
    """
    resp = await client.analyze_code(code, "python", "optimize")
    print(f"Análise: {resp.content}")
    
    # 4. Simular A2A
    resp = await client.execute_with_a2a(
        "criar sistema de login",
        agents=["security", "backend", "frontend"]
    )
    print(f"A2A: {resp.content}")

if __name__ == "__main__":
    asyncio.run(main())
```

## 🐳 Docker (Opcional)

```dockerfile
FROM node:18-slim

# Instalar Python
RUN apt-get update && apt-get install -y python3 python3-pip

# Instalar Claude CLI
RUN npm install -g @anthropic-ai/claude-code

# Copiar código
WORKDIR /app
COPY . .

# Instalar dependências Python
RUN pip3 install fastapi uvicorn

# Expor porta
EXPOSE 8000

# Comando para iniciar
CMD ["python3", "src/api_server_cli.py"]
```

## 🔍 Troubleshooting

### Claude CLI não encontrado
```bash
# Verificar se está instalado
which claude

# Reinstalar se necessário
npm uninstall -g @anthropic-ai/claude-code
npm install -g @anthropic-ai/claude-code
```

### Erro de autenticação
```bash
# Refazer login
claude logout
claude login
```

### Comando não responde
```bash
# Testar diretamente no terminal
claude -p "teste"

# Se funcionar no terminal mas não no Python,
# verificar PATH do Python
```

## 📊 Comparação: API Key vs CLI

| Aspecto | Com API Key | Com CLI (este) |
|---------|------------|----------------|
| **Configuração** | Precisa API key | Só login |
| **Custo** | Pago por token | Gratuito* |
| **Velocidade** | Mais rápido | Um pouco mais lento |
| **Escalabilidade** | Alta | Média |
| **Simplicidade** | Média | Alta |

*Gratuito dentro dos limites da sua conta Claude

## 🎉 Pronto para Usar!

Agora você tem uma integração completa com Claude Code **sem precisar de API key**!

1. ✅ Cliente Python que usa CLI
2. ✅ API REST completa
3. ✅ Suporte a streaming/SSE
4. ✅ Simulação A2A
5. ✅ Testes automatizados

Basta fazer `claude login` uma vez e está pronto!