# 🚀 GUIA DE INSTALAÇÃO RÁPIDA - Claude Code SEM API Key

## ✅ Passo 1: Instalar Claude CLI

```bash
# Instalar o Claude Code CLI globalmente
npm install -g @anthropic-ai/claude-code

# Verificar instalação
claude --version
```

## ✅ Passo 2: Fazer Login no Claude

```bash
# Fazer login (abrirá o navegador)
claude login

# Seguir as instruções no navegador para autenticar
```

## ✅ Passo 3: Instalar Dependências Python

```bash
# Criar ambiente virtual (opcional mas recomendado)
python3 -m venv venv
source venv/bin/activate  # No Windows: venv\Scripts\activate

# Instalar FastAPI e outras dependências
pip install fastapi uvicorn aiohttp
```

## ✅ Passo 4: Testar se Funciona

```bash
# Teste rápido no terminal
claude -p "Diga olá"

# Se funcionar, teste o script Python
python run_without_api_key.py demo
```

## 🎯 Como Usar

### Modo Interativo (Chat)
```bash
python run_without_api_key.py
```

### Modo Demonstração
```bash
python run_without_api_key.py demo
```

### Modo Batch (Múltiplos Prompts)
```bash
python run_without_api_key.py batch --prompts "O que é Python?" "Crie uma função de soma" "Explique recursão"
```

### API Server (Para integrar com sua UI)
```bash
# Iniciar servidor
python src/api_server_cli.py

# API disponível em http://localhost:8000
# Documentação em http://localhost:8000/docs
```

## 🔥 Exemplo Rápido

```python
from claude_cli_client_fixed import ClaudeCLIClient
import asyncio

async def exemplo():
    # Criar cliente (SEM API KEY!)
    client = ClaudeCLIClient()
    
    # Fazer uma pergunta
    response = await client.query_simple("Crie uma função Python para calcular fatorial")
    
    if response.success:
        print(response.content)
    else:
        print(f"Erro: {response.error}")

# Executar
asyncio.run(exemplo())
```

## ⚡ Comandos Úteis no Modo Interativo

- Digite qualquer pergunta normalmente
- `/code <descrição>` - Gerar código
- `/analyze` - Analisar código (cole o código)
- `/a2a <tarefa>` - Executar com múltiplas perspectivas
- `sair` - Encerrar

## 🎉 Pronto!

Agora você pode usar o Claude Code **completamente GRÁTIS** sem precisar de API key!

- ✅ Sem configurar variáveis de ambiente
- ✅ Sem pagar por tokens
- ✅ Usando sua conta Claude já autenticada
- ✅ Todas as funcionalidades disponíveis

## 🆘 Problemas Comuns

### Claude não encontrado
```bash
# Verificar se está no PATH
which claude

# Se não estiver, adicionar ao PATH ou usar caminho completo
export PATH=$PATH:/usr/local/bin
```

### Erro de autenticação
```bash
# Refazer login
claude logout
claude login
```

### Comando não responde
```bash
# Testar diretamente
claude -p "teste"

# Se funcionar no terminal mas não no Python, verificar PATH
```

## 📝 Observações

- O Claude CLI usa a autenticação da sua conta Claude.ai
- Não há limite de tokens além dos limites da sua conta
- Funciona offline após o login (cache local)
- Pode ser um pouco mais lento que a API direta