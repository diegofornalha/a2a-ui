#!/bin/bash

# Script para iniciar o sistema completo

echo "======================================"
echo "🚀 CLAUDE CODE - SEM API KEY"
echo "======================================"

# Cores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# Verificar Claude CLI
echo -e "\n${YELLOW}Verificando Claude CLI...${NC}"
if command -v claude &> /dev/null; then
    echo -e "${GREEN}✅ Claude CLI instalado${NC}"
    claude --version
else
    echo -e "${RED}❌ Claude CLI não encontrado${NC}"
    echo "Instale com: npm install -g @anthropic-ai/claude-code"
    exit 1
fi

# Verificar Python
echo -e "\n${YELLOW}Verificando Python...${NC}"
if command -v python3 &> /dev/null; then
    echo -e "${GREEN}✅ Python instalado${NC}"
    python3 --version
else
    echo -e "${RED}❌ Python não encontrado${NC}"
    exit 1
fi

# Menu
echo -e "\n${YELLOW}Escolha uma opção:${NC}"
echo "1) Interface Gráfica (Gradio)"
echo "2) API Server"
echo "3) Modo Interativo (Terminal)"
echo "4) Demonstração"
echo "5) Testar Conexão"

read -p "Opção: " choice

case $choice in
    1)
        echo -e "\n${GREEN}Iniciando Interface Gráfica...${NC}"
        python3 ui_complete.py
        ;;
    2)
        echo -e "\n${GREEN}Iniciando API Server...${NC}"
        python3 src/api_server_cli.py
        ;;
    3)
        echo -e "\n${GREEN}Iniciando Modo Interativo...${NC}"
        python3 run_without_api_key.py
        ;;
    4)
        echo -e "\n${GREEN}Executando Demonstração...${NC}"
        python3 run_without_api_key.py demo
        ;;
    5)
        echo -e "\n${GREEN}Testando Conexão...${NC}"
        python3 src/claude_cli_client_fixed.py
        ;;
    *)
        echo -e "${RED}Opção inválida${NC}"
        exit 1
        ;;
esac