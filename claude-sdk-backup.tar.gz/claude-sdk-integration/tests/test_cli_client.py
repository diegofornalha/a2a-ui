"""
Testes para o cliente CLI (sem API key)
"""

import asyncio
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from claude_cli_client import ClaudeCLIClient


async def test_cli_installation():
    """Testa se o CLI está instalado"""
    print("\n🧪 TESTE 1: Verificando instalação do CLI")
    print("-" * 40)
    
    try:
        client = ClaudeCLIClient()
        print("✅ Claude CLI está instalado e acessível")
        return True
    except RuntimeError as e:
        print(f"❌ {str(e)}")
        print("\nPara instalar:")
        print("  npm install -g @anthropic-ai/claude-code")
        print("\nDepois configure:")
        print("  claude login")
        return False


async def test_cli_connection():
    """Testa conexão via CLI"""
    print("\n🧪 TESTE 2: Testando conexão")
    print("-" * 40)
    
    try:
        client = ClaudeCLIClient()
        connected = await client.test_connection()
        
        if connected:
            print("✅ Claude CLI está funcionando corretamente")
            return True
        else:
            print("❌ Claude CLI não respondeu como esperado")
            print("\nVerifique se está logado:")
            print("  claude login")
            return False
    except Exception as e:
        print(f"❌ Erro: {str(e)}")
        return False


async def test_simple_query():
    """Testa query simples"""
    print("\n🧪 TESTE 3: Query simples")
    print("-" * 40)
    
    try:
        client = ClaudeCLIClient()
        response = await client.query_simple("Responda em uma palavra: funcionando?")
        
        if response.success:
            print(f"✅ Resposta recebida: {response.content[:100]}")
            return True
        else:
            print(f"❌ Erro: {response.error}")
            return False
    except Exception as e:
        print(f"❌ Erro: {str(e)}")
        return False


async def test_code_generation():
    """Testa geração de código"""
    print("\n🧪 TESTE 4: Geração de código")
    print("-" * 40)
    
    try:
        client = ClaudeCLIClient()
        response = await client.generate_code(
            "função que retorna 'Hello World'",
            language="python"
        )
        
        if response.success and len(response.content) > 10:
            print("✅ Código gerado com sucesso")
            print(f"Preview: {response.content[:150]}...")
            return True
        else:
            print(f"❌ Falha na geração: {response.error}")
            return False
    except Exception as e:
        print(f"❌ Erro: {str(e)}")
        return False


async def test_streaming():
    """Testa streaming de resposta"""
    print("\n🧪 TESTE 5: Streaming")
    print("-" * 40)
    
    try:
        client = ClaudeCLIClient()
        lines = []
        
        print("Recebendo stream: ", end="")
        async for line in client.stream_response("Liste 3 números"):
            lines.append(line)
            print(".", end="", flush=True)
        
        print()
        if lines:
            print(f"✅ Streaming funcionando ({len(lines)} linhas)")
            return True
        else:
            print("❌ Nenhuma linha recebida no stream")
            return False
    except Exception as e:
        print(f"❌ Erro: {str(e)}")
        return False


async def test_a2a_simulation():
    """Testa simulação A2A"""
    print("\n🧪 TESTE 6: Simulação A2A")
    print("-" * 40)
    
    try:
        client = ClaudeCLIClient()
        response = await client.execute_with_a2a(
            "criar uma função de soma simples",
            agents=["developer", "tester"]
        )
        
        if response.success:
            print("✅ Simulação A2A executada")
            print(f"Preview: {response.content[:150]}...")
            return True
        else:
            print(f"❌ Erro: {response.error}")
            return False
    except Exception as e:
        print(f"❌ Erro: {str(e)}")
        return False


async def main():
    """Executa todos os testes"""
    print("\n" + "="*50)
    print("🧪 TESTES DO CLAUDE CLI CLIENT")
    print("   (Sem necessidade de API key)")
    print("="*50)
    
    tests = [
        ("Instalação do CLI", test_cli_installation),
        ("Conexão via CLI", test_cli_connection),
        ("Query Simples", test_simple_query),
        ("Geração de Código", test_code_generation),
        ("Streaming", test_streaming),
        ("Simulação A2A", test_a2a_simulation)
    ]
    
    results = []
    
    for name, test_func in tests:
        result = await test_func()
        results.append((name, result))
        await asyncio.sleep(0.5)  # Pequena pausa entre testes
    
    # Resumo
    print("\n" + "="*50)
    print("📊 RESUMO DOS TESTES")
    print("="*50)
    
    passed = sum(1 for _, r in results if r)
    total = len(results)
    
    for name, result in results:
        status = "✅" if result else "❌"
        print(f"  {status} {name}")
    
    print(f"\nTotal: {passed}/{total} testes passaram")
    
    if passed == total:
        print("\n🎉 SUCESSO TOTAL!")
        print("✅ Claude CLI está pronto para uso SEM API key!")
    elif passed >= 2:
        print("\n⚠️ Sistema parcialmente funcional")
        print("Verifique os testes que falharam")
    else:
        print("\n❌ Sistema não está funcional")
        print("Configure o Claude CLI primeiro:")
        print("  1. npm install -g @anthropic-ai/claude-code")
        print("  2. claude login")
    
    return passed == total


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)