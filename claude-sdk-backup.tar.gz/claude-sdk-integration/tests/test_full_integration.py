"""
Teste completo de integração: SDK + API + UI
"""

import asyncio
import subprocess
import time
import sys
import os
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from ui_client import ClaudeUIClient, ClaudeAPIConfig
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class IntegrationTester:
    """Classe para testar integração completa"""
    
    def __init__(self):
        self.api_process = None
        self.api_url = "http://localhost:8000"
        self.results = {}
    
    async def start_api_server(self):
        """Inicia o servidor API em background"""
        print("\n🚀 Iniciando servidor API...")
        
        # Comando para iniciar o servidor
        cmd = [
            sys.executable,
            str(Path(__file__).parent.parent / "src" / "api_server_improved.py")
        ]
        
        try:
            self.api_process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env={**os.environ, "ANTHROPIC_API_KEY": os.getenv("ANTHROPIC_API_KEY", "")}
            )
            
            # Aguardar servidor iniciar
            print("   Aguardando servidor iniciar...")
            await asyncio.sleep(3)
            
            # Verificar se está rodando
            if self.api_process.poll() is not None:
                stderr = self.api_process.stderr.read().decode()
                print(f"❌ Servidor falhou ao iniciar: {stderr}")
                return False
            
            print("✅ Servidor API iniciado")
            return True
            
        except Exception as e:
            print(f"❌ Erro ao iniciar servidor: {str(e)}")
            return False
    
    def stop_api_server(self):
        """Para o servidor API"""
        if self.api_process:
            print("\n🛑 Parando servidor API...")
            self.api_process.terminate()
            self.api_process.wait(timeout=5)
            print("✅ Servidor parado")
    
    async def test_health(self, client: ClaudeUIClient):
        """Testa health check"""
        print("\n🧪 TESTE 1: Health Check")
        try:
            health = await client.health_check()
            self.results['health'] = health.get('ok', False)
            
            print(f"   API Key configurada: {'✅' if health.get('has_anthropic_key') else '❌'}")
            print(f"   CLI instalado: {'✅' if health.get('cli_installed') else '❌'}")
            print(f"   Status: {'✅ OK' if health.get('ok') else '❌ Problema'}")
            
            return health.get('ok', False)
        except Exception as e:
            print(f"   ❌ Erro: {str(e)}")
            self.results['health'] = False
            return False
    
    async def test_simple_query(self, client: ClaudeUIClient):
        """Testa query simples"""
        print("\n🧪 TESTE 2: Query Simples")
        try:
            response = await client.ask(
                prompt="Responda apenas: 'Sistema funcionando'",
                include_metadata=True
            )
            
            success = "funcionando" in response.get('result', '').lower()
            self.results['simple_query'] = success
            
            if success:
                print(f"   ✅ Resposta recebida: {response['result'][:50]}...")
                if response.get('duration_ms'):
                    print(f"   ⏱️ Tempo: {response['duration_ms']}ms")
            else:
                print(f"   ❌ Resposta inesperada: {response.get('result', 'N/A')}")
            
            return success
        except Exception as e:
            print(f"   ❌ Erro: {str(e)}")
            self.results['simple_query'] = False
            return False
    
    async def test_streaming(self, client: ClaudeUIClient):
        """Testa streaming"""
        print("\n🧪 TESTE 3: Streaming")
        try:
            chunks = []
            print("   Recebendo: ", end="")
            
            async for chunk in client.ask_stream("Conte de 1 a 3"):
                chunks.append(chunk)
                print(".", end="", flush=True)
            
            print()
            full_response = "".join(chunks)
            success = len(full_response) > 0
            self.results['streaming'] = success
            
            if success:
                print(f"   ✅ Streaming funcionando ({len(chunks)} chunks)")
                print(f"   Resposta: {full_response[:100]}...")
            else:
                print("   ❌ Nenhum chunk recebido")
            
            return success
        except Exception as e:
            print(f"   ❌ Erro: {str(e)}")
            self.results['streaming'] = False
            return False
    
    async def test_sse(self, client: ClaudeUIClient):
        """Testa Server-Sent Events"""
        print("\n🧪 TESTE 4: Server-Sent Events")
        try:
            events = []
            chunks = []
            
            async for event in client.ask_sse("Diga 'teste SSE'"):
                events.append(event)
                
                if event['type'] == 'chunk':
                    chunks.append(event['content'])
                elif event['type'] == 'done':
                    break
            
            success = len(chunks) > 0
            self.results['sse'] = success
            
            if success:
                print(f"   ✅ SSE funcionando ({len(events)} eventos)")
                print(f"   Resposta: {''.join(chunks)[:100]}...")
            else:
                print("   ❌ Nenhum evento recebido")
            
            return success
        except Exception as e:
            print(f"   ❌ Erro: {str(e)}")
            self.results['sse'] = False
            return False
    
    async def test_code_analysis(self, client: ClaudeUIClient):
        """Testa análise de código"""
        print("\n🧪 TESTE 5: Análise de Código")
        
        code = """
def hello(name):
    print(f"Hello, {name}!")
    return name.upper()
"""
        
        try:
            response = await client.analyze_code(
                code=code,
                language="python",
                analysis_type="explain"
            )
            
            success = len(response.get('result', '')) > 50
            self.results['code_analysis'] = success
            
            if success:
                print(f"   ✅ Análise recebida")
                print(f"   Resultado: {response['result'][:150]}...")
            else:
                print("   ❌ Análise vazia ou muito curta")
            
            return success
        except Exception as e:
            print(f"   ❌ Erro: {str(e)}")
            self.results['code_analysis'] = False
            return False
    
    async def test_a2a(self, client: ClaudeUIClient):
        """Testa integração A2A"""
        print("\n🧪 TESTE 6: Integração A2A")
        try:
            response = await client.execute_a2a(
                task="Criar uma função simples para somar dois números",
                agents=["coder"],
                topology="hierarchical"
            )
            
            success = len(response.get('result', '')) > 20
            self.results['a2a'] = success
            
            if success:
                print(f"   ✅ A2A executado")
                print(f"   Resultado: {response['result'][:200]}...")
            else:
                print("   ❌ Resposta A2A vazia")
            
            return success
        except Exception as e:
            print(f"   ❌ Erro: {str(e)}")
            self.results['a2a'] = False
            return False
    
    async def run_all_tests(self):
        """Executa todos os testes de integração"""
        print("\n" + "="*60)
        print("🚀 TESTE DE INTEGRAÇÃO COMPLETA")
        print("   SDK + API + UI")
        print("="*60)
        
        # Verificar API key
        if not os.getenv("ANTHROPIC_API_KEY"):
            print("\n❌ ERRO: ANTHROPIC_API_KEY não configurada!")
            print("Configure com: export ANTHROPIC_API_KEY='sua-chave-aqui'")
            return False
        
        # Iniciar servidor API
        if not await self.start_api_server():
            print("❌ Não foi possível iniciar o servidor API")
            return False
        
        # Aguardar servidor estabilizar
        await asyncio.sleep(2)
        
        # Configurar cliente
        config = ClaudeAPIConfig(
            base_url=self.api_url,
            api_key=None,  # Configure se necessário
            timeout=30
        )
        
        # Executar testes
        try:
            async with ClaudeUIClient(config) as client:
                # Lista de testes
                tests = [
                    self.test_health(client),
                    self.test_simple_query(client),
                    self.test_streaming(client),
                    self.test_sse(client),
                    self.test_code_analysis(client),
                    self.test_a2a(client)
                ]
                
                # Executar sequencialmente para melhor diagnóstico
                for test in tests:
                    await test
                    await asyncio.sleep(1)  # Pequena pausa entre testes
        
        finally:
            # Parar servidor
            self.stop_api_server()
        
        # Resumo dos resultados
        self.print_summary()
        
        # Retornar se todos passaram
        return all(self.results.values())
    
    def print_summary(self):
        """Imprime resumo dos testes"""
        print("\n" + "="*60)
        print("📊 RESUMO DOS TESTES")
        print("="*60)
        
        total = len(self.results)
        passed = sum(1 for v in self.results.values() if v)
        
        for test_name, result in self.results.items():
            status = "✅ PASSOU" if result else "❌ FALHOU"
            print(f"   {test_name.replace('_', ' ').title()}: {status}")
        
        print(f"\n   Total: {passed}/{total} testes passaram")
        
        if passed == total:
            print("\n🎉 SUCESSO! Todos os testes passaram!")
            print("✅ Sua UI está pronta para usar o Claude Code SDK!")
        else:
            print(f"\n⚠️ {total - passed} teste(s) falharam")
            print("Verifique a configuração e tente novamente")


async def test_ui_only():
    """Testa apenas o cliente UI (assume que o servidor está rodando)"""
    print("\n🧪 Testando cliente UI (servidor deve estar rodando)...")
    
    config = ClaudeAPIConfig(
        base_url="http://localhost:8000",
        api_key=None
    )
    
    async with ClaudeUIClient(config) as client:
        try:
            # Teste rápido
            health = await client.health_check()
            print(f"✅ API está {'online' if health.get('ok') else 'offline'}")
            
            if health.get('ok'):
                response = await client.ask("Diga 'teste OK'")
                print(f"✅ Resposta: {response['result']}")
            
        except Exception as e:
            print(f"❌ Erro: {str(e)}")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "ui-only":
        # Testar apenas cliente UI
        asyncio.run(test_ui_only())
    else:
        # Teste completo de integração
        tester = IntegrationTester()
        success = asyncio.run(tester.run_all_tests())
        sys.exit(0 if success else 1)