"""
Teste básico para verificar se o Claude Code SDK está funcionando
"""

import asyncio
import os
import sys
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))


async def test_sdk_import():
    """Testa se o SDK pode ser importado"""
    try:
        from claude_code_sdk import query, ClaudeCodeOptions
        print("✅ Claude Code SDK importado com sucesso")
        return True
    except ImportError as e:
        print(f"❌ Erro ao importar SDK: {e}")
        print("\nInstale o SDK com:")
        print("  pip install claude-code-sdk")
        return False


async def test_api_key():
    """Verifica se a API key está configurada"""
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if api_key:
        print(f"✅ API Key configurada ({len(api_key)} caracteres)")
        return True
    else:
        print("❌ ANTHROPIC_API_KEY não configurada")
        print("\nConfigure com:")
        print("  export ANTHROPIC_API_KEY='sua-chave-aqui'")
        return False


async def test_simple_query():
    """Testa uma query simples ao Claude"""
    if not os.getenv("ANTHROPIC_API_KEY"):
        print("⏭️ Pulando teste de query (API key não configurada)")
        return False
    
    try:
        from claude_code_sdk import query, ClaudeCodeOptions, AssistantMessage, TextBlock
        
        print("🔄 Enviando query de teste...")
        
        options = ClaudeCodeOptions(
            max_turns=1,
            temperature=0.5
        )
        
        chunks = []
        async for msg in query(prompt="Responda apenas: OK", options=options):
            if isinstance(msg, AssistantMessage):
                for block in msg.content:
                    if isinstance(block, TextBlock) and block.text:
                        chunks.append(block.text)
        
        result = "".join(chunks)
        if "OK" in result.upper():
            print(f"✅ Query funcionando! Resposta: {result[:50]}")
            return True
        else:
            print(f"⚠️ Resposta inesperada: {result[:50]}")
            return False
            
    except Exception as e:
        print(f"❌ Erro na query: {e}")
        return False


async def test_cli_installed():
    """Verifica se o Claude CLI está instalado"""
    import subprocess
    
    try:
        result = subprocess.run(
            ["claude", "--version"],
            capture_output=True,
            text=True,
            timeout=2
        )
        if result.returncode == 0:
            print("✅ Claude CLI instalado")
            return True
        else:
            print("❌ Claude CLI com problema")
            return False
    except FileNotFoundError:
        print("❌ Claude CLI não encontrado")
        print("\nInstale com:")
        print("  npm install -g @anthropic-ai/claude-code")
        return False
    except Exception as e:
        print(f"⚠️ Erro ao verificar CLI: {e}")
        return False


async def main():
    """Executa todos os testes básicos"""
    print("\n" + "="*50)
    print("🧪 TESTE BÁSICO DO CLAUDE CODE SDK")
    print("="*50 + "\n")
    
    tests = [
        ("Importação do SDK", test_sdk_import),
        ("API Key", test_api_key),
        ("Claude CLI", test_cli_installed),
        ("Query Simples", test_simple_query)
    ]
    
    results = []
    
    for name, test_func in tests:
        print(f"\n📋 Testando: {name}")
        print("-" * 30)
        result = await test_func()
        results.append((name, result))
        print()
    
    # Resumo
    print("="*50)
    print("📊 RESUMO DOS TESTES")
    print("="*50)
    
    passed = 0
    failed = 0
    
    for name, result in results:
        status = "✅ PASSOU" if result else "❌ FALHOU"
        print(f"  {name}: {status}")
        if result:
            passed += 1
        else:
            failed += 1
    
    print(f"\nTotal: {passed} passou, {failed} falhou")
    
    if passed == len(tests):
        print("\n🎉 SUCESSO! Todos os testes passaram!")
        print("✅ O Claude Code SDK está pronto para uso!")
    elif passed > 0:
        print(f"\n⚠️ Alguns testes falharam ({failed}/{len(tests)})")
        print("Verifique as mensagens acima para resolver os problemas")
    else:
        print("\n❌ Todos os testes falharam")
        print("Siga as instruções acima para configurar o ambiente")
    
    return passed == len(tests)


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)