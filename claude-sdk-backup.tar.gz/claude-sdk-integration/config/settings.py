"""
Configurações para integração Claude Code SDK + A2A
"""

import os
from typing import Optional, List, Dict, Any
from pydantic_settings import BaseSettings
from pydantic import Field, validator
from dotenv import load_dotenv

# Carregar variáveis de ambiente
load_dotenv()


class ClaudeSettings(BaseSettings):
    """Configurações do Claude Code SDK"""
    
    # API Configuration
    api_key: str = Field(
        default_factory=lambda: os.getenv("ANTHROPIC_API_KEY", ""),
        description="Chave API da Anthropic"
    )
    
    # Model Configuration
    model: str = Field(
        default="claude-3-opus-20240229",
        description="Modelo do Claude a usar"
    )
    
    max_tokens: int = Field(
        default=4096,
        description="Máximo de tokens na resposta"
    )
    
    temperature: float = Field(
        default=0.7,
        description="Temperatura para geração (0-1)"
    )
    
    # Connection Settings
    timeout: int = Field(
        default=30000,
        description="Timeout em milissegundos"
    )
    
    retry_attempts: int = Field(
        default=3,
        description="Tentativas de reconexão"
    )
    
    # Feature Flags
    enable_streaming: bool = Field(
        default=True,
        description="Habilitar streaming de respostas"
    )
    
    enable_tools: bool = Field(
        default=True,
        description="Habilitar uso de ferramentas MCP"
    )
    
    enable_a2a: bool = Field(
        default=True,
        description="Habilitar integração A2A"
    )
    
    # A2A Configuration
    a2a_agents: List[str] = Field(
        default_factory=lambda: [
            "coder",
            "reviewer", 
            "tester",
            "planner",
            "researcher",
            "system-architect",
            "performance-benchmarker"
        ],
        description="Agentes A2A disponíveis"
    )
    
    a2a_default_topology: str = Field(
        default="hierarchical",
        description="Topologia padrão do swarm (mesh, hierarchical, ring, star)"
    )
    
    a2a_max_agents: int = Field(
        default=5,
        description="Número máximo de agentes simultâneos"
    )
    
    # Output Configuration
    output_format: str = Field(
        default="json",
        description="Formato de saída (json, text, markdown)"
    )
    
    verbose: bool = Field(
        default=True,
        description="Modo verbose para debug"
    )
    
    # File Operations
    allowed_directories: List[str] = Field(
        default_factory=lambda: [
            "/Users/agents/Desktop/claude-20x/A2A-UI/.conductor/marseille"
        ],
        description="Diretórios permitidos para operações"
    )
    
    max_file_size: int = Field(
        default=10_000_000,  # 10MB
        description="Tamanho máximo de arquivo em bytes"
    )
    
    # Security
    enable_command_execution: bool = Field(
        default=True,
        description="Permitir execução de comandos shell"
    )
    
    allowed_commands: List[str] = Field(
        default_factory=lambda: [
            "ls", "cat", "grep", "find", "git", "npm", "python", "pip"
        ],
        description="Comandos permitidos para execução"
    )
    
    @validator("api_key")
    def validate_api_key(cls, v):
        if not v:
            raise ValueError(
                "API Key não configurada. Configure ANTHROPIC_API_KEY ou use 'claude config set apiKey'"
            )
        return v
    
    @validator("temperature")
    def validate_temperature(cls, v):
        if not 0 <= v <= 1:
            raise ValueError("Temperature deve estar entre 0 e 1")
        return v
    
    class Config:
        env_prefix = "CLAUDE_"
        env_file = ".env"
        case_sensitive = False


class MigrationSettings(BaseSettings):
    """Configurações para migração do Gemini"""
    
    # Mapeamento de modelos
    model_mapping: Dict[str, str] = Field(
        default_factory=lambda: {
            "gemini-pro": "claude-3-opus-20240229",
            "gemini-pro-vision": "claude-3-opus-20240229",
            "gemini-1.5-pro": "claude-3-opus-20240229",
            "gemini-1.5-flash": "claude-3-sonnet-20240229"
        },
        description="Mapeamento de modelos Gemini para Claude"
    )
    
    # Feature mapping
    feature_mapping: Dict[str, str] = Field(
        default_factory=lambda: {
            "generate_content": "query",
            "stream_generate_content": "query_stream",
            "count_tokens": "count_tokens",
            "embed_content": "embed"
        },
        description="Mapeamento de funções Gemini para Claude"
    )
    
    # Comportamento
    auto_migrate: bool = Field(
        default=True,
        description="Migrar automaticamente chamadas Gemini"
    )
    
    preserve_gemini_format: bool = Field(
        default=False,
        description="Manter formato de resposta do Gemini"
    )


class Settings(BaseSettings):
    """Configurações gerais do sistema"""
    
    claude: ClaudeSettings = Field(
        default_factory=ClaudeSettings
    )
    
    migration: MigrationSettings = Field(
        default_factory=MigrationSettings
    )
    
    # Logging
    log_level: str = Field(
        default="INFO",
        description="Nível de log (DEBUG, INFO, WARNING, ERROR)"
    )
    
    log_file: Optional[str] = Field(
        default="claude_integration.log",
        description="Arquivo de log"
    )
    
    # Performance
    cache_enabled: bool = Field(
        default=True,
        description="Habilitar cache de respostas"
    )
    
    cache_ttl: int = Field(
        default=3600,
        description="TTL do cache em segundos"
    )
    
    # Testing
    test_mode: bool = Field(
        default=False,
        description="Modo de teste (usa mock responses)"
    )
    
    test_api_key: str = Field(
        default="test-key-123",
        description="API key para testes"
    )
    
    def to_claude_options(self) -> Dict[str, Any]:
        """Converte settings para ClaudeCodeOptions"""
        return {
            "apiKey": self.claude.api_key,
            "model": self.claude.model,
            "maxTokens": self.claude.max_tokens,
            "temperature": self.claude.temperature,
            "timeout": self.claude.timeout,
            "stream": self.claude.enable_streaming,
            "tools": self.claude.enable_tools,
            "verbose": self.claude.verbose,
            "outputFormat": self.claude.output_format
        }
    
    class Config:
        env_file = ".env"
        case_sensitive = False


# Instância global de configurações
settings = Settings()

# Exportar configurações principais
claude_settings = settings.claude
migration_settings = settings.migration