#!/usr/bin/env python3
"""
Interface UI Completa para Claude Code (SEM API KEY)
Usa o Claude CLI local já autenticado
"""

import gradio as gr
import asyncio
import sys
from pathlib import Path
from typing import List, Tuple
import json
from datetime import datetime

# Adicionar src ao path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from claude_cli_client_fixed import ClaudeCLIClient

# Cliente global
client = None

# Histórico de conversas
conversation_history: List[Tuple[str, str]] = []

# Agentes disponíveis para simulação A2A
AGENTS = [
    "developer", "tester", "reviewer", "architect",
    "security", "performance", "documentation", "devops"
]

# Tipos de análise
ANALYSIS_TYPES = {
    "explain": "Explicar o código",
    "review": "Revisar e sugerir melhorias",
    "optimize": "Otimizar performance",
    "analyze": "Análise completa"
}


async def initialize_client():
    """Inicializa o cliente Claude CLI"""
    global client
    try:
        client = ClaudeCLIClient()
        if await client.test_connection():
            return "✅ Claude CLI conectado e funcionando!"
        else:
            return "❌ Claude CLI não está respondendo. Faça: claude login"
    except Exception as e:
        return f"❌ Erro ao inicializar: {str(e)}"


async def chat_with_claude(prompt: str, save_history: bool = True):
    """Chat simples com Claude"""
    if not client:
        return "❌ Cliente não inicializado. Recarregue a página."
    
    try:
        response = await client.query_simple(prompt)
        
        if response.success:
            if save_history:
                conversation_history.append((prompt, response.content))
            return response.content
        else:
            return f"❌ Erro: {response.error}"
    except Exception as e:
        return f"❌ Erro: {str(e)}"


async def generate_code(description: str, language: str, framework: str = ""):
    """Gera código com Claude"""
    if not client:
        return "❌ Cliente não inicializado."
    
    try:
        response = await client.generate_code(
            description,
            language,
            framework if framework else None
        )
        
        if response.success:
            conversation_history.append(
                (f"Gerar {language}: {description}", response.content)
            )
            return response.content
        else:
            return f"❌ Erro: {response.error}"
    except Exception as e:
        return f"❌ Erro: {str(e)}"


async def analyze_code(code: str, language: str, analysis_type: str):
    """Analisa código com Claude"""
    if not client:
        return "❌ Cliente não inicializado."
    
    try:
        response = await client.analyze_code(code, language, analysis_type)
        
        if response.success:
            return response.content
        else:
            return f"❌ Erro: {response.error}"
    except Exception as e:
        return f"❌ Erro: {str(e)}"


async def execute_a2a(task: str, agents: List[str]):
    """Executa tarefa com simulação A2A"""
    if not client:
        return "❌ Cliente não inicializado."
    
    if not agents:
        agents = ["developer", "tester", "reviewer"]
    
    try:
        response = await client.execute_with_a2a(task, agents)
        
        if response.success:
            conversation_history.append(
                (f"A2A: {task}", response.content)
            )
            return response.content
        else:
            return f"❌ Erro: {response.error}"
    except Exception as e:
        return f"❌ Erro: {str(e)}"


def export_history():
    """Exporta histórico como JSON"""
    if not conversation_history:
        return "Nenhuma conversa para exportar"
    
    export_data = {
        "timestamp": datetime.now().isoformat(),
        "conversations": [
            {"prompt": p, "response": r} 
            for p, r in conversation_history
        ]
    }
    
    return json.dumps(export_data, indent=2, ensure_ascii=False)


def clear_history():
    """Limpa histórico"""
    global conversation_history
    conversation_history = []
    return "Histórico limpo!"


# Interface Gradio
with gr.Blocks(
    title="Claude Code - Sem API Key",
    theme=gr.themes.Soft(),
    css="""
    .gradio-container {
        max-width: 1200px;
        margin: auto;
    }
    #status-box {
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 20px;
    }
    """
) as demo:
    
    gr.Markdown(
        """
        # 🤖 Claude Code - Interface Completa (SEM API KEY!)
        
        Esta interface usa o **Claude CLI local** já autenticado. Não precisa de API key!
        
        **Requisitos:**
        1. `npm install -g @anthropic-ai/claude-code`
        2. `claude login` (fazer uma vez)
        """
    )
    
    # Status
    with gr.Row():
        status = gr.Textbox(
            label="Status da Conexão",
            value="🔄 Inicializando...",
            interactive=False,
            elem_id="status-box"
        )
        refresh_btn = gr.Button("🔄 Reconectar", size="sm")
    
    with gr.Tabs():
        
        # Tab 1: Chat
        with gr.TabItem("💬 Chat"):
            chat_input = gr.Textbox(
                label="Sua pergunta",
                placeholder="Digite sua pergunta aqui...",
                lines=3
            )
            
            with gr.Row():
                chat_submit = gr.Button("🚀 Enviar", variant="primary")
                chat_clear = gr.Button("🗑️ Limpar")
            
            chat_output = gr.Textbox(
                label="Resposta do Claude",
                lines=15,
                interactive=False
            )
        
        # Tab 2: Geração de Código
        with gr.TabItem("💻 Gerar Código"):
            with gr.Row():
                with gr.Column():
                    code_desc = gr.Textbox(
                        label="Descrição do código",
                        placeholder="Ex: função para validar email",
                        lines=3
                    )
                    
                    with gr.Row():
                        code_lang = gr.Dropdown(
                            choices=["python", "javascript", "typescript", "java", "go", "rust"],
                            value="python",
                            label="Linguagem"
                        )
                        
                        code_framework = gr.Textbox(
                            label="Framework (opcional)",
                            placeholder="Ex: FastAPI, React, Django"
                        )
                    
                    code_gen_btn = gr.Button("🎨 Gerar Código", variant="primary")
            
            code_output = gr.Code(
                label="Código Gerado",
                language="python",
                lines=20
            )
        
        # Tab 3: Análise de Código
        with gr.TabItem("🔍 Analisar Código"):
            code_input = gr.Code(
                label="Cole seu código aqui",
                language="python",
                lines=10
            )
            
            with gr.Row():
                analyze_lang = gr.Dropdown(
                    choices=["python", "javascript", "typescript", "java", "go", "rust"],
                    value="python",
                    label="Linguagem"
                )
                
                analyze_type = gr.Dropdown(
                    choices=list(ANALYSIS_TYPES.keys()),
                    value="explain",
                    label="Tipo de Análise"
                )
            
            analyze_btn = gr.Button("🔍 Analisar", variant="primary")
            
            analyze_output = gr.Textbox(
                label="Resultado da Análise",
                lines=15,
                interactive=False
            )
        
        # Tab 4: A2A (Multi-Agentes)
        with gr.TabItem("🐝 A2A Multi-Agentes"):
            a2a_task = gr.Textbox(
                label="Tarefa para os agentes",
                placeholder="Ex: Criar um sistema de autenticação com JWT",
                lines=4
            )
            
            a2a_agents = gr.CheckboxGroup(
                choices=AGENTS,
                value=["developer", "tester", "reviewer"],
                label="Selecione os agentes (perspectivas)"
            )
            
            a2a_btn = gr.Button("🚀 Executar com A2A", variant="primary")
            
            a2a_output = gr.Textbox(
                label="Resultado A2A",
                lines=20,
                interactive=False
            )
        
        # Tab 5: Histórico
        with gr.TabItem("📜 Histórico"):
            with gr.Row():
                export_btn = gr.Button("💾 Exportar JSON")
                clear_btn = gr.Button("🗑️ Limpar Histórico")
            
            history_output = gr.Textbox(
                label="Histórico Exportado",
                lines=20,
                interactive=False
            )
        
        # Tab 6: Ajuda
        with gr.TabItem("❓ Ajuda"):
            gr.Markdown(
                """
                ## 📚 Como Usar
                
                ### 1️⃣ Primeiro Uso
                ```bash
                # Instalar Claude CLI
                npm install -g @anthropic-ai/claude-code
                
                # Fazer login (uma vez só)
                claude login
                ```
                
                ### 2️⃣ Chat
                - Digite qualquer pergunta
                - Claude responderá usando o CLI local
                - Sem limite de tokens!
                
                ### 3️⃣ Gerar Código
                - Descreva o que você quer
                - Escolha a linguagem
                - Opcionalmente, especifique um framework
                
                ### 4️⃣ Analisar Código
                - Cole seu código
                - Escolha o tipo de análise
                - Receba feedback detalhado
                
                ### 5️⃣ A2A Multi-Agentes
                - Descreva uma tarefa complexa
                - Selecione múltiplas perspectivas
                - Claude analisará sob cada perspectiva
                
                ### ⚡ Vantagens
                - ✅ **Sem API Key necessária**
                - ✅ **Sem custos por token**
                - ✅ **Usa sua conta Claude local**
                - ✅ **Todas as funcionalidades**
                
                ### 🆘 Problemas?
                
                **Claude não responde:**
                ```bash
                claude logout
                claude login
                ```
                
                **Comando não encontrado:**
                ```bash
                npm install -g @anthropic-ai/claude-code
                ```
                
                **Teste manual:**
                ```bash
                claude -p "teste"
                ```
                """
            )
    
    # Event Handlers
    async def on_load():
        """Executado ao carregar a interface"""
        status_msg = await initialize_client()
        return status_msg
    
    # Conectar eventos
    demo.load(
        fn=on_load,
        outputs=status
    )
    
    refresh_btn.click(
        fn=initialize_client,
        outputs=status
    )
    
    chat_submit.click(
        fn=chat_with_claude,
        inputs=chat_input,
        outputs=chat_output
    )
    
    chat_clear.click(
        fn=lambda: ("", ""),
        outputs=[chat_input, chat_output]
    )
    
    code_gen_btn.click(
        fn=generate_code,
        inputs=[code_desc, code_lang, code_framework],
        outputs=code_output
    )
    
    analyze_btn.click(
        fn=analyze_code,
        inputs=[code_input, analyze_lang, analyze_type],
        outputs=analyze_output
    )
    
    a2a_btn.click(
        fn=execute_a2a,
        inputs=[a2a_task, a2a_agents],
        outputs=a2a_output
    )
    
    export_btn.click(
        fn=export_history,
        outputs=history_output
    )
    
    clear_btn.click(
        fn=clear_history,
        outputs=history_output
    )


# Executar
if __name__ == "__main__":
    print("\n" + "="*60)
    print("🚀 CLAUDE CODE UI - SEM API KEY!")
    print("="*60)
    print("\n✅ Esta interface usa o Claude CLI local")
    print("✅ Não precisa de API key")
    print("✅ Gratuito (usa sua conta Claude)")
    print("\n📍 Acesse: http://localhost:7860")
    print("\nPressione Ctrl+C para parar")
    
    demo.queue().launch(
        server_name="0.0.0.0",
        server_port=7860,
        share=False
    )