"""
Exemplo de uso do Claude Code SDK com A2A para criar uma aplicação completa
"""

import asyncio
import os
from pathlib import Path
import sys

# Adicionar src ao path
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from claude_code_sdk import query, ClaudeCodeOptions, AssistantMessage, TextBlock


async def create_todo_app_with_a2a():
    """
    Exemplo: Criar uma aplicação TODO completa usando agentes A2A
    """
    
    print("🚀 Criando aplicação TODO com agentes A2A...")
    print("-" * 50)
    
    # Tarefa complexa para os agentes
    prompt = """
    Use uma abordagem multi-agente A2A para criar uma aplicação TODO completa:
    
    REQUISITOS:
    1. Backend em Python com FastAPI
    2. Banco de dados SQLite com SQLAlchemy
    3. Frontend simples em HTML/JS
    4. API REST com CRUD completo
    5. Testes unitários
    
    AGENTES A2A A USAR:
    - system-architect: Desenhar a arquitetura
    - backend-dev: Implementar o backend
    - coder: Criar o frontend
    - tester: Escrever os testes
    - reviewer: Revisar o código
    
    TOPOLOGIA: hierarchical
    
    Coordene os agentes para entregar:
    1. Estrutura de pastas do projeto
    2. Código do backend (models.py, main.py, database.py)
    3. Frontend (index.html com JavaScript)
    4. Testes (test_api.py)
    5. README com instruções
    
    Retorne o código completo e funcional de todos os arquivos.
    """
    
    options = ClaudeCodeOptions(
        max_turns=5,
        system_prompt="Você é um coordenador de agentes A2A especializado em criar aplicações completas. Use os agentes de forma eficiente e paralela.",
        temperature=0.7
    )
    
    print("🤖 Coordenando agentes A2A...")
    print("   • system-architect: Desenhando arquitetura")
    print("   • backend-dev: Implementando API")
    print("   • coder: Criando frontend")
    print("   • tester: Escrevendo testes")
    print("   • reviewer: Revisando código")
    print()
    
    result = []
    try:
        async for msg in query(prompt=prompt, options=options):
            if isinstance(msg, AssistantMessage):
                for block in msg.content:
                    if isinstance(block, TextBlock) and block.text:
                        result.append(block.text)
                        print(".", end="", flush=True)
        
        print("\n✅ Aplicação criada com sucesso!")
        return "".join(result)
        
    except Exception as e:
        print(f"\n❌ Erro: {str(e)}")
        return None


async def analyze_codebase_with_a2a():
    """
    Exemplo: Analisar um codebase existente com múltiplos agentes
    """
    
    print("\n🔍 Analisando codebase com agentes A2A...")
    print("-" * 50)
    
    prompt = """
    Use agentes A2A para analisar este codebase Python:
    
    CÓDIGO:
    ```python
    # main.py
    from fastapi import FastAPI, HTTPException
    from pydantic import BaseModel
    from typing import List, Optional
    import sqlite3
    
    app = FastAPI()
    
    class Item(BaseModel):
        id: Optional[int] = None
        title: str
        description: str
        completed: bool = False
    
    def get_db():
        conn = sqlite3.connect('todos.db')
        conn.row_factory = sqlite3.Row
        return conn
    
    @app.post("/items/")
    def create_item(item: Item):
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO items (title, description, completed) VALUES (?, ?, ?)",
            (item.title, item.description, item.completed)
        )
        conn.commit()
        return {"id": cursor.lastrowid}
    
    @app.get("/items/")
    def read_items():
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM items")
        return [dict(row) for row in cursor.fetchall()]
    ```
    
    AGENTES A USAR:
    - code-analyzer: Analisar qualidade do código
    - security-manager: Verificar vulnerabilidades
    - performance-benchmarker: Avaliar performance
    - reviewer: Fazer revisão geral
    
    Forneça:
    1. Análise de qualidade
    2. Problemas de segurança encontrados
    3. Sugestões de performance
    4. Código refatorado e melhorado
    """
    
    options = ClaudeCodeOptions(
        max_turns=3,
        system_prompt="Você coordena agentes especializados em análise de código. Seja detalhado e forneça soluções práticas.",
        temperature=0.5
    )
    
    print("🤖 Agentes analisando código...")
    print("   • code-analyzer: Verificando qualidade")
    print("   • security-manager: Buscando vulnerabilidades")
    print("   • performance-benchmarker: Avaliando performance")
    print("   • reviewer: Compilando relatório")
    print()
    
    result = []
    try:
        async for msg in query(prompt=prompt, options=options):
            if isinstance(msg, AssistantMessage):
                for block in msg.content:
                    if isinstance(block, TextBlock) and block.text:
                        result.append(block.text)
        
        print("✅ Análise concluída!")
        return "".join(result)
        
    except Exception as e:
        print(f"❌ Erro: {str(e)}")
        return None


async def generate_tests_with_a2a():
    """
    Exemplo: Gerar suite de testes completa com agentes especializados
    """
    
    print("\n🧪 Gerando testes com agentes A2A...")
    print("-" * 50)
    
    prompt = """
    Use agentes A2A para criar uma suite de testes completa:
    
    CÓDIGO A TESTAR:
    ```python
    def calculate_discount(price, discount_percent):
        if discount_percent < 0 or discount_percent > 100:
            raise ValueError("Discount must be between 0 and 100")
        return price * (1 - discount_percent / 100)
    
    def validate_email(email):
        import re
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
    
    class ShoppingCart:
        def __init__(self):
            self.items = []
        
        def add_item(self, item, quantity=1):
            self.items.append({"item": item, "quantity": quantity})
        
        def get_total(self):
            return sum(item["item"]["price"] * item["quantity"] for item in self.items)
    ```
    
    AGENTES:
    - tester: Criar testes unitários
    - tdd-london-swarm: Adicionar mocks e stubs
    - production-validator: Validar casos reais
    
    Gere:
    1. Testes unitários com pytest
    2. Testes com mocks
    3. Testes de integração
    4. Casos edge e validação
    """
    
    options = ClaudeCodeOptions(
        max_turns=3,
        system_prompt="Você coordena agentes de teste. Gere testes completos e bem estruturados.",
        temperature=0.6
    )
    
    print("🤖 Agentes criando testes...")
    print("   • tester: Escrevendo testes unitários")
    print("   • tdd-london-swarm: Adicionando mocks")
    print("   • production-validator: Validando casos reais")
    print()
    
    result = []
    try:
        async for msg in query(prompt=prompt, options=options):
            if isinstance(msg, AssistantMessage):
                for block in msg.content:
                    if isinstance(block, TextBlock) and block.text:
                        result.append(block.text)
        
        print("✅ Suite de testes criada!")
        return "".join(result)
        
    except Exception as e:
        print(f"❌ Erro: {str(e)}")
        return None


async def main():
    """Executa todos os exemplos"""
    
    print("\n" + "="*60)
    print("🎯 EXEMPLOS DE USO DO CLAUDE CODE SDK COM A2A")
    print("="*60)
    
    # Verificar API key
    if not os.getenv("ANTHROPIC_API_KEY"):
        print("\n❌ ERRO: ANTHROPIC_API_KEY não configurada!")
        print("Configure com: export ANTHROPIC_API_KEY='sua-chave-aqui'")
        return
    
    # Exemplo 1: Criar aplicação TODO
    print("\n📱 EXEMPLO 1: Criar Aplicação TODO")
    todo_result = await create_todo_app_with_a2a()
    if todo_result:
        print("\nPrimeiros 500 caracteres do resultado:")
        print(todo_result[:500] + "...")
    
    # Exemplo 2: Analisar codebase
    print("\n" + "="*60)
    print("🔍 EXEMPLO 2: Analisar Codebase")
    analysis_result = await analyze_codebase_with_a2a()
    if analysis_result:
        print("\nPrimeiros 500 caracteres da análise:")
        print(analysis_result[:500] + "...")
    
    # Exemplo 3: Gerar testes
    print("\n" + "="*60)
    print("🧪 EXEMPLO 3: Gerar Suite de Testes")
    tests_result = await generate_tests_with_a2a()
    if tests_result:
        print("\nPrimeiros 500 caracteres dos testes:")
        print(tests_result[:500] + "...")
    
    print("\n" + "="*60)
    print("✅ TODOS OS EXEMPLOS CONCLUÍDOS!")
    print("="*60)


if __name__ == "__main__":
    asyncio.run(main())