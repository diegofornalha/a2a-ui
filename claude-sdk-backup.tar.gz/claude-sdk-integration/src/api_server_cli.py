"""
API Server que usa Claude CLI diretamente (sem necessidade de API key)
"""

from fastapi import FastAPI, HTTPException, Header, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, AsyncGenerator
import json
import logging
import os

from claude_cli_client import ClaudeCLIClient, ClaudeResponse

# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Criar app FastAPI
app = FastAPI(
    title="Claude CLI Integration API",
    description="API que usa Claude Code CLI local (sem API key)",
    version="2.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Cliente CLI global
cli_client: Optional[ClaudeCLIClient] = None

# Modelos
class QueryRequest(BaseModel):
    """Request para query"""
    prompt: str = Field(..., description="Prompt para o Claude")
    context: Optional[str] = Field(None, description="Contexto adicional")
    stream: bool = Field(False, description="Se deve usar streaming")


class CodeAnalysisRequest(BaseModel):
    """Request para análise de código"""
    code: str = Field(..., description="Código para analisar")
    language: str = Field("python", description="Linguagem do código")
    task: str = Field("analyze", description="Tipo de análise")


class CodeGenerationRequest(BaseModel):
    """Request para geração de código"""
    description: str = Field(..., description="Descrição do código")
    language: str = Field("python", description="Linguagem alvo")
    framework: Optional[str] = Field(None, description="Framework")


class A2ARequest(BaseModel):
    """Request para execução estilo A2A"""
    task: str = Field(..., description="Tarefa para executar")
    agents: Optional[list[str]] = Field(None, description="Agentes/papéis")


class FileAnalysisRequest(BaseModel):
    """Request para análise de arquivo"""
    file_path: str = Field(..., description="Caminho do arquivo")
    instruction: str = Field(..., description="O que fazer com o arquivo")


class APIResponse(BaseModel):
    """Response padrão"""
    success: bool
    data: Optional[Any] = None
    error: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)


# Auth opcional
API_KEY_ENV = "API_SERVER_KEY"

def optional_api_key(x_api_key: Optional[str] = Header(default=None)) -> None:
    """Validação opcional de API key"""
    expected = os.getenv(API_KEY_ENV)
    if expected and expected != "":
        if not x_api_key or x_api_key != expected:
            logger.warning("Tentativa de acesso sem API key válida")
            raise HTTPException(status_code=401, detail="Unauthorized")


# Startup/Shutdown
@app.on_event("startup")
async def startup_event():
    """Inicializa cliente CLI"""
    global cli_client
    try:
        cli_client = ClaudeCLIClient()
        connected = await cli_client.test_connection()
        if connected:
            logger.info("✅ Claude CLI conectado com sucesso")
        else:
            logger.warning("⚠️ Claude CLI iniciado mas conexão não verificada")
    except Exception as e:
        logger.error(f"❌ Erro ao inicializar Claude CLI: {str(e)}")
        # Permitir que a API inicie mesmo sem CLI


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup"""
    logger.info("🔌 Desconectando Claude CLI")


# Endpoints
@app.get("/")
async def root():
    """Informações da API"""
    return {
        "name": "Claude CLI Integration API",
        "version": "2.0.0",
        "status": "online",
        "cli_available": cli_client is not None,
        "requires_api_key": False,
        "endpoints": {
            "query": "/api/query",
            "analyze": "/api/analyze",
            "generate": "/api/generate",
            "a2a": "/api/a2a",
            "file": "/api/file",
            "health": "/api/health"
        }
    }


@app.get("/api/health")
async def health_check():
    """Health check"""
    if not cli_client:
        return APIResponse(
            success=False,
            error="CLI client not initialized"
        )
    
    connected = await cli_client.test_connection()
    return APIResponse(
        success=connected,
        data={
            "status": "healthy" if connected else "degraded",
            "cli_available": True,
            "api_key_required": False
        }
    )


@app.post("/api/query", dependencies=[Depends(optional_api_key)])
async def query_claude(request: QueryRequest):
    """Query simples ao Claude via CLI"""
    if not cli_client:
        raise HTTPException(status_code=503, detail="CLI client not initialized")
    
    try:
        if request.stream:
            # Streaming
            async def generate():
                async for line in cli_client.stream_response(request.prompt):
                    yield json.dumps({"line": line}) + "\n"
            
            return StreamingResponse(
                generate(),
                media_type="application/x-ndjson"
            )
        else:
            # Query normal
            response = await cli_client.query_simple(
                request.prompt,
                request.context
            )
            
            return APIResponse(
                success=response.success,
                data=response.content,
                error=response.error,
                metadata=response.metadata or {}
            )
    
    except Exception as e:
        logger.error(f"Erro na query: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/analyze", dependencies=[Depends(optional_api_key)])
async def analyze_code(request: CodeAnalysisRequest):
    """Analisa código via CLI"""
    if not cli_client:
        raise HTTPException(status_code=503, detail="CLI client not initialized")
    
    try:
        response = await cli_client.analyze_code(
            request.code,
            request.language,
            request.task
        )
        
        return APIResponse(
            success=response.success,
            data=response.content,
            error=response.error,
            metadata={
                "language": request.language,
                "task": request.task
            }
        )
    
    except Exception as e:
        logger.error(f"Erro na análise: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/generate", dependencies=[Depends(optional_api_key)])
async def generate_code(request: CodeGenerationRequest):
    """Gera código via CLI"""
    if not cli_client:
        raise HTTPException(status_code=503, detail="CLI client not initialized")
    
    try:
        response = await cli_client.generate_code(
            request.description,
            request.language,
            request.framework
        )
        
        return APIResponse(
            success=response.success,
            data=response.content,
            error=response.error,
            metadata={
                "language": request.language,
                "framework": request.framework
            }
        )
    
    except Exception as e:
        logger.error(f"Erro na geração: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/a2a", dependencies=[Depends(optional_api_key)])
async def execute_a2a(request: A2ARequest):
    """Executa tarefa estilo A2A via CLI"""
    if not cli_client:
        raise HTTPException(status_code=503, detail="CLI client not initialized")
    
    try:
        response = await cli_client.execute_with_a2a(
            request.task,
            request.agents
        )
        
        return APIResponse(
            success=response.success,
            data=response.content,
            error=response.error,
            metadata={
                "agents": request.agents,
                "task": request.task
            }
        )
    
    except Exception as e:
        logger.error(f"Erro no A2A: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/file", dependencies=[Depends(optional_api_key)])
async def analyze_file(request: FileAnalysisRequest):
    """Analisa arquivo via CLI"""
    if not cli_client:
        raise HTTPException(status_code=503, detail="CLI client not initialized")
    
    try:
        response = await cli_client.execute_with_file(
            request.file_path,
            request.instruction
        )
        
        return APIResponse(
            success=response.success,
            data=response.content,
            error=response.error,
            metadata={
                "file": request.file_path
            }
        )
    
    except Exception as e:
        logger.error(f"Erro com arquivo: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


# SSE endpoint
@app.post("/api/sse", dependencies=[Depends(optional_api_key)])
async def query_sse(request: QueryRequest):
    """Server-Sent Events para streaming"""
    if not cli_client:
        raise HTTPException(status_code=503, detail="CLI client not initialized")
    
    async def sse_generator() -> AsyncGenerator[bytes, None]:
        try:
            # Evento inicial
            yield f"data: {json.dumps({'type': 'start'})}\n\n".encode()
            
            # Stream das linhas
            async for line in cli_client.stream_response(request.prompt):
                event = {
                    "type": "line",
                    "content": line
                }
                yield f"data: {json.dumps(event)}\n\n".encode()
            
            # Evento final
            yield f"data: {json.dumps({'type': 'done'})}\n\n".encode()
            
        except Exception as e:
            error_event = {
                "type": "error",
                "message": str(e)
            }
            yield f"data: {json.dumps(error_event)}\n\n".encode()
    
    return StreamingResponse(
        sse_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive"
        }
    )


# Executar servidor
if __name__ == "__main__":
    import uvicorn
    
    print("\n🚀 Iniciando Claude CLI Integration API")
    print("📍 Sem necessidade de API key!")
    print("🔧 Usando Claude CLI local")
    print("\n📚 Documentação em: http://localhost:8000/docs")
    print("🔗 Endpoints:")
    print("   POST /api/query - Query simples")
    print("   POST /api/analyze - Análise de código")
    print("   POST /api/generate - Geração de código")
    print("   POST /api/a2a - Execução estilo A2A")
    print("   POST /api/file - Análise de arquivo")
    print("   POST /api/sse - Server-Sent Events")
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        reload=True
    )