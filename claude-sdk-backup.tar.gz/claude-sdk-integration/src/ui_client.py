"""
Cliente Python para consumir a API do Claude Code SDK
Exemplo de como sua UI pode interagir com o servidor
"""

import asyncio
import aiohttp
import json
from typing import Optional, AsyncGenerator, Dict, Any
from dataclasses import dataclass
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class ClaudeAPIConfig:
    """Configuração do cliente API"""
    base_url: str = "http://localhost:8000"
    api_key: Optional[str] = None
    timeout: int = 30


class ClaudeUIClient:
    """Cliente para UI consumir a API do Claude Code SDK"""
    
    def __init__(self, config: Optional[ClaudeAPIConfig] = None):
        self.config = config or ClaudeAPIConfig()
        self.session: Optional[aiohttp.ClientSession] = None
        
    async def __aenter__(self):
        """Inicializa sessão HTTP"""
        headers = {}
        if self.config.api_key:
            headers["X-API-Key"] = self.config.api_key
            
        self.session = aiohttp.ClientSession(
            headers=headers,
            timeout=aiohttp.ClientTimeout(total=self.config.timeout)
        )
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Fecha sessão HTTP"""
        if self.session:
            await self.session.close()
    
    async def health_check(self) -> Dict[str, Any]:
        """Verifica saúde da API"""
        async with self.session.get(f"{self.config.base_url}/health") as resp:
            return await resp.json()
    
    async def ask(
        self,
        prompt: str,
        max_turns: int = 2,
        system_prompt: Optional[str] = None,
        include_metadata: bool = True
    ) -> Dict[str, Any]:
        """
        Faz uma pergunta ao Claude e retorna resposta completa
        
        Args:
            prompt: Pergunta/prompt para o Claude
            max_turns: Número máximo de turnos
            system_prompt: System prompt opcional
            include_metadata: Se deve incluir metadados
            
        Returns:
            Dict com resultado e metadados
        """
        payload = {
            "prompt": prompt,
            "max_turns": max_turns,
            "include_metadata": include_metadata
        }
        
        if system_prompt:
            payload["system_prompt"] = system_prompt
        
        async with self.session.post(
            f"{self.config.base_url}/ask",
            json=payload
        ) as resp:
            if resp.status != 200:
                error = await resp.text()
                raise Exception(f"API Error ({resp.status}): {error}")
            
            return await resp.json()
    
    async def ask_stream(
        self,
        prompt: str,
        max_turns: int = 2,
        system_prompt: Optional[str] = None
    ) -> AsyncGenerator[str, None]:
        """
        Faz uma pergunta ao Claude com streaming de resposta
        
        Args:
            prompt: Pergunta/prompt para o Claude
            max_turns: Número máximo de turnos
            system_prompt: System prompt opcional
            
        Yields:
            Chunks de texto da resposta
        """
        payload = {
            "prompt": prompt,
            "max_turns": max_turns,
            "include_metadata": False  # Metadados vêm no final
        }
        
        if system_prompt:
            payload["system_prompt"] = system_prompt
        
        async with self.session.post(
            f"{self.config.base_url}/ask/stream",
            json=payload
        ) as resp:
            if resp.status != 200:
                error = await resp.text()
                raise Exception(f"API Error ({resp.status}): {error}")
            
            async for chunk in resp.content:
                text = chunk.decode('utf-8')
                
                # Detectar metadados ou erros
                if text.startswith("[METADATA]"):
                    metadata = json.loads(text.replace("[METADATA]", ""))
                    logger.info(f"Metadados recebidos: {metadata}")
                elif text.startswith("[ERROR]"):
                    error_msg = text.replace("[ERROR]", "").strip()
                    logger.error(f"Erro no stream: {error_msg}")
                    raise Exception(error_msg)
                else:
                    yield text
    
    async def ask_sse(
        self,
        prompt: str,
        max_turns: int = 2,
        system_prompt: Optional[str] = None
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Faz uma pergunta ao Claude usando Server-Sent Events
        
        Args:
            prompt: Pergunta/prompt para o Claude
            max_turns: Número máximo de turnos
            system_prompt: System prompt opcional
            
        Yields:
            Eventos SSE como dicionários
        """
        payload = {
            "prompt": prompt,
            "max_turns": max_turns,
            "include_metadata": True
        }
        
        if system_prompt:
            payload["system_prompt"] = system_prompt
        
        async with self.session.post(
            f"{self.config.base_url}/ask/sse",
            json=payload
        ) as resp:
            if resp.status != 200:
                error = await resp.text()
                raise Exception(f"API Error ({resp.status}): {error}")
            
            async for line in resp.content:
                text = line.decode('utf-8').strip()
                
                if text.startswith("data: "):
                    try:
                        event_data = json.loads(text[6:])
                        yield event_data
                    except json.JSONDecodeError:
                        logger.warning(f"Falha ao decodificar evento SSE: {text}")
    
    async def execute_a2a(
        self,
        task: str,
        agents: Optional[list[str]] = None,
        topology: str = "hierarchical"
    ) -> Dict[str, Any]:
        """
        Executa tarefa usando agentes A2A
        
        Args:
            task: Tarefa para executar
            agents: Lista de agentes (padrão: coder, reviewer, tester)
            topology: Topologia do swarm
            
        Returns:
            Resultado da execução A2A
        """
        payload = {
            "task": task,
            "topology": topology
        }
        
        if agents:
            payload["agents"] = agents
        
        async with self.session.post(
            f"{self.config.base_url}/a2a",
            json=payload
        ) as resp:
            if resp.status != 200:
                error = await resp.text()
                raise Exception(f"API Error ({resp.status}): {error}")
            
            return await resp.json()
    
    async def analyze_code(
        self,
        code: str,
        language: str = "python",
        analysis_type: str = "review"
    ) -> Dict[str, Any]:
        """
        Analisa código usando Claude
        
        Args:
            code: Código para analisar
            language: Linguagem do código
            analysis_type: Tipo de análise (review, optimize, explain, security, performance)
            
        Returns:
            Resultado da análise
        """
        payload = {
            "code": code,
            "language": language,
            "analysis_type": analysis_type
        }
        
        async with self.session.post(
            f"{self.config.base_url}/analyze",
            json=payload
        ) as resp:
            if resp.status != 200:
                error = await resp.text()
                raise Exception(f"API Error ({resp.status}): {error}")
            
            return await resp.json()


# Exemplo de uso da UI
async def example_ui_usage():
    """Exemplo de como usar o cliente na UI"""
    
    # Configurar cliente
    config = ClaudeAPIConfig(
        base_url="http://localhost:8000",
        api_key=None  # Configure se necessário
    )
    
    async with ClaudeUIClient(config) as client:
        print("\n" + "="*50)
        print("🚀 EXEMPLO DE USO DO CLIENTE UI")
        print("="*50)
        
        # 1. Health check
        print("\n1️⃣ Verificando saúde da API...")
        health = await client.health_check()
        print(f"   Status: {'✅ OK' if health['ok'] else '❌ Problema'}")
        print(f"   CLI instalado: {health.get('cli_installed', False)}")
        
        # 2. Pergunta simples
        print("\n2️⃣ Fazendo pergunta simples...")
        response = await client.ask(
            prompt="Explique Python em uma linha",
            include_metadata=True
        )
        print(f"   Resposta: {response['result'][:100]}...")
        if response.get('duration_ms'):
            print(f"   Tempo: {response['duration_ms']}ms")
        
        # 3. Streaming
        print("\n3️⃣ Testando streaming...")
        print("   Resposta: ", end="")
        async for chunk in client.ask_stream("Conte de 1 a 3"):
            print(chunk, end="", flush=True)
        print()
        
        # 4. SSE (Server-Sent Events)
        print("\n4️⃣ Testando SSE...")
        async for event in client.ask_sse("Diga olá"):
            if event['type'] == 'chunk':
                print(f"   Chunk: {event['content']}", end="")
            elif event['type'] == 'metadata':
                print(f"\n   Metadados: custo=${event.get('cost', 'N/A')}")
            elif event['type'] == 'done':
                print("   ✅ Concluído")
                break
        
        # 5. Análise de código
        print("\n5️⃣ Analisando código...")
        code = """
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)
"""
        analysis = await client.analyze_code(
            code=code,
            language="python",
            analysis_type="optimize"
        )
        print(f"   Análise: {analysis['result'][:200]}...")
        
        # 6. A2A
        print("\n6️⃣ Executando com A2A...")
        a2a_result = await client.execute_a2a(
            task="Criar uma função para validar email",
            agents=["coder", "tester"],
            topology="hierarchical"
        )
        print(f"   Resultado A2A: {a2a_result['result'][:200]}...")
        
        print("\n" + "="*50)
        print("✅ TODOS OS TESTES CONCLUÍDOS!")
        print("="*50)


# Interface de linha de comando simples
async def interactive_ui():
    """Interface interativa para testar"""
    config = ClaudeAPIConfig()
    
    print("\n🤖 Claude Code SDK - Interface Interativa")
    print("Digite 'sair' para encerrar")
    print("-" * 40)
    
    async with ClaudeUIClient(config) as client:
        while True:
            try:
                prompt = input("\n💬 Você: ").strip()
                
                if prompt.lower() in ['sair', 'exit', 'quit']:
                    print("👋 Até logo!")
                    break
                
                if not prompt:
                    continue
                
                # Detectar comandos especiais
                if prompt.startswith("/analyze "):
                    # Análise de código
                    code = prompt[9:]
                    print("\n🤖 Claude (analisando código):")
                    result = await client.analyze_code(code)
                    print(result['result'])
                    
                elif prompt.startswith("/a2a "):
                    # Execução A2A
                    task = prompt[5:]
                    print("\n🤖 Claude (executando com A2A):")
                    result = await client.execute_a2a(task)
                    print(result['result'])
                    
                elif prompt == "/stream":
                    # Modo streaming
                    prompt = input("   Prompt para streaming: ")
                    print("\n🤖 Claude (streaming): ", end="")
                    async for chunk in client.ask_stream(prompt):
                        print(chunk, end="", flush=True)
                    print()
                    
                else:
                    # Pergunta normal
                    print("\n🤖 Claude: ", end="")
                    response = await client.ask(prompt)
                    print(response['result'])
                    
                    if response.get('duration_ms'):
                        print(f"\n⏱️ Tempo: {response['duration_ms']}ms")
                        
            except KeyboardInterrupt:
                print("\n\n👋 Interrompido!")
                break
            except Exception as e:
                print(f"\n❌ Erro: {str(e)}")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "interactive":
        # Modo interativo
        asyncio.run(interactive_ui())
    else:
        # Executar exemplos
        asyncio.run(example_ui_usage())