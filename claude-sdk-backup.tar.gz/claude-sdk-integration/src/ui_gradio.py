"""
Interface UI usando Gradio com streaming e múltiplas funcionalidades
"""

import gradio as gr
import asyncio
from typing import Optional, List, Tuple
import json
import os

from claude_code_sdk import (
    query,
    ClaudeCodeOptions,
    AssistantMessage,
    ResultMessage,
    TextBlock,
    CLINotFoundError,
    ProcessError,
    CLIJSONDecodeError,
)

from config.settings import (
    DEFAULT_MAX_TURNS,
    DEFAULT_SYSTEM_PROMPT,
    claude_settings
)

# Histórico de conversas
conversation_history: List[Tuple[str, str]] = []

# Agentes A2A disponíveis
A2A_AGENTS = [
    "coder", "reviewer", "tester", "planner", "researcher",
    "system-architect", "backend-dev", "mobile-dev", "ml-developer",
    "api-docs", "code-analyzer", "performance-benchmarker"
]

# Topologias disponíveis
A2A_TOPOLOGIES = ["hierarchical", "mesh", "ring", "star"]

# Tipos de análise de código
ANALYSIS_TYPES = ["review", "optimize", "explain", "security", "performance"]


async def ask_claude_async(
    prompt: str,
    system_prompt: str,
    max_turns: int,
    temperature: float,
    stream_output: bool = False
):
    """Função assíncrona para consultar Claude"""
    
    if not os.getenv("ANTHROPIC_API_KEY"):
        return "❌ Erro: ANTHROPIC_API_KEY não configurada. Configure com: export ANTHROPIC_API_KEY='sua-chave'"
    
    options = ClaudeCodeOptions(
        max_turns=max_turns,
        system_prompt=system_prompt or DEFAULT_SYSTEM_PROMPT,
        temperature=temperature,
    )

    chunks = []
    metadata = {}
    
    try:
        async for msg in query(prompt=prompt, options=options):
            if isinstance(msg, AssistantMessage):
                for block in msg.content:
                    if isinstance(block, TextBlock) and block.text:
                        chunks.append(block.text)
                        if stream_output:
                            # Para streaming, retornaria chunk por chunk
                            yield "".join(chunks)
            elif isinstance(msg, ResultMessage):
                metadata = {
                    "cost": getattr(msg, "total_cost_usd", None),
                    "duration_ms": getattr(msg, "duration_ms", None),
                    "num_turns": getattr(msg, "num_turns", None),
                    "session_id": getattr(msg, "session_id", None),
                }
        
        result = "".join(chunks)
        
        # Adicionar metadados se disponíveis
        if metadata and metadata.get("cost"):
            result += f"\n\n---\n📊 Metadados:\n"
            result += f"• Custo: ${metadata['cost']:.4f}\n"
            result += f"• Duração: {metadata.get('duration_ms', 'N/A')}ms\n"
            result += f"• Turnos: {metadata.get('num_turns', 'N/A')}"
        
        # Salvar no histórico
        conversation_history.append((prompt, result))
        
        if not stream_output:
            return result
            
    except CLINotFoundError:
        return "❌ Claude Code CLI não encontrado. Instale com: npm i -g @anthropic-ai/claude-code"
    except CLIJSONDecodeError:
        return "❌ Falha ao interpretar a saída do CLI"
    except ProcessError as e:
        return f"❌ Processo do CLI falhou (exit {e.exit_code})"
    except Exception as e:
        return f"❌ Erro: {str(e)}"


async def analyze_code_async(
    code: str,
    language: str,
    analysis_type: str,
    system_prompt: Optional[str] = None
):
    """Analisa código com Claude"""
    
    prompts = {
        "review": f"Faça uma revisão completa deste código {language}, identificando bugs, problemas de segurança, e sugestões de melhoria:\n\n```{language}\n{code}\n```",
        "optimize": f"Otimize este código {language} para melhor performance e legibilidade:\n\n```{language}\n{code}\n```",
        "explain": f"Explique detalhadamente o que este código {language} faz:\n\n```{language}\n{code}\n```",
        "security": f"Analise este código {language} focando em vulnerabilidades de segurança:\n\n```{language}\n{code}\n```",
        "performance": f"Analise a performance deste código {language} e sugira otimizações:\n\n```{language}\n{code}\n```"
    }
    
    prompt = prompts.get(analysis_type, prompts["review"])
    
    return await ask_claude_async(
        prompt=prompt,
        system_prompt=system_prompt or f"Você é um especialista em {language} com foco em code review e boas práticas.",
        max_turns=2,
        temperature=0.7
    )


async def execute_a2a_async(
    task: str,
    agents: List[str],
    topology: str,
    max_turns: int = 3
):
    """Executa tarefa com agentes A2A"""
    
    agent_list = ", ".join(agents) if agents else "coder, reviewer, tester"
    
    prompt = f"""
    Execute esta tarefa usando uma abordagem multi-agente A2A:
    
    Tarefa: {task}
    
    Use os seguintes agentes especializados: {agent_list}
    
    Topologia do swarm: {topology}
    
    Coordene os agentes para:
    1. Analisar os requisitos da tarefa
    2. Distribuir responsabilidades entre os agentes
    3. Executar as subtarefas em paralelo quando possível
    4. Integrar os resultados
    5. Retornar a solução completa com código funcional
    
    Seja específico e inclua código completo.
    """
    
    return await ask_claude_async(
        prompt=prompt,
        system_prompt="Você é um coordenador de agentes A2A especializado em desenvolvimento de software. Use uma abordagem sistemática e paralela.",
        max_turns=max_turns,
        temperature=0.7
    )


def clear_history():
    """Limpa o histórico de conversas"""
    global conversation_history
    conversation_history = []
    return "Histórico limpo!"


def export_history():
    """Exporta o histórico como JSON"""
    if not conversation_history:
        return "Nenhuma conversa para exportar"
    
    export_data = {
        "conversations": [
            {"prompt": p, "response": r} 
            for p, r in conversation_history
        ]
    }
    
    return json.dumps(export_data, indent=2, ensure_ascii=False)


# Interface Gradio
with gr.Blocks(
    title="Claude Code SDK - Interface Completa",
    theme=gr.themes.Soft(),
    css="""
    .gradio-container {
        font-family: 'Inter', sans-serif;
    }
    .gr-button-primary {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }
    """
) as demo:
    
    gr.Markdown(
        """
        # 🤖 Claude Code SDK - Interface Completa
        
        Integração completa com Claude Code SDK, incluindo:
        - 💬 Chat interativo com Claude
        - 📝 Análise de código
        - 🐝 Execução com agentes A2A
        - 📊 Métricas e metadados
        """
    )
    
    with gr.Tabs():
        
        # Tab 1: Chat
        with gr.TabItem("💬 Chat"):
            with gr.Row():
                with gr.Column(scale=3):
                    chat_prompt = gr.Textbox(
                        label="Prompt",
                        lines=4,
                        placeholder="Digite sua pergunta ou comando...",
                        value=""
                    )
                    
                    with gr.Row():
                        chat_submit = gr.Button("🚀 Enviar", variant="primary")
                        chat_clear = gr.Button("🗑️ Limpar")
                    
                    chat_output = gr.Textbox(
                        label="Resposta",
                        lines=15,
                        interactive=False
                    )
                
                with gr.Column(scale=1):
                    chat_system = gr.Textbox(
                        label="System Prompt",
                        lines=3,
                        value=DEFAULT_SYSTEM_PROMPT
                    )
                    
                    chat_turns = gr.Slider(
                        minimum=1,
                        maximum=10,
                        step=1,
                        value=DEFAULT_MAX_TURNS,
                        label="Max Turns"
                    )
                    
                    chat_temp = gr.Slider(
                        minimum=0,
                        maximum=1,
                        step=0.1,
                        value=0.7,
                        label="Temperature"
                    )
                    
                    chat_stream = gr.Checkbox(
                        label="Streaming",
                        value=False
                    )
        
        # Tab 2: Análise de Código
        with gr.TabItem("📝 Análise de Código"):
            with gr.Row():
                with gr.Column():
                    code_input = gr.Code(
                        label="Código para Analisar",
                        language="python",
                        lines=10
                    )
                    
                    with gr.Row():
                        code_lang = gr.Dropdown(
                            choices=["python", "javascript", "typescript", "java", "go", "rust", "cpp"],
                            value="python",
                            label="Linguagem"
                        )
                        
                        code_analysis = gr.Dropdown(
                            choices=ANALYSIS_TYPES,
                            value="review",
                            label="Tipo de Análise"
                        )
                    
                    code_submit = gr.Button("🔍 Analisar", variant="primary")
                
                with gr.Column():
                    code_output = gr.Textbox(
                        label="Resultado da Análise",
                        lines=15,
                        interactive=False
                    )
        
        # Tab 3: A2A
        with gr.TabItem("🐝 Agentes A2A"):
            with gr.Row():
                with gr.Column():
                    a2a_task = gr.Textbox(
                        label="Tarefa para A2A",
                        lines=4,
                        placeholder="Descreva a tarefa que os agentes devem executar...",
                        value="Criar uma API REST com autenticação JWT"
                    )
                    
                    a2a_agents = gr.CheckboxGroup(
                        choices=A2A_AGENTS,
                        value=["coder", "reviewer", "tester"],
                        label="Agentes"
                    )
                    
                    a2a_topology = gr.Radio(
                        choices=A2A_TOPOLOGIES,
                        value="hierarchical",
                        label="Topologia"
                    )
                    
                    a2a_turns = gr.Slider(
                        minimum=1,
                        maximum=10,
                        step=1,
                        value=3,
                        label="Max Turns"
                    )
                    
                    a2a_submit = gr.Button("🚀 Executar A2A", variant="primary")
                
                with gr.Column():
                    a2a_output = gr.Textbox(
                        label="Resultado A2A",
                        lines=20,
                        interactive=False
                    )
        
        # Tab 4: Histórico
        with gr.TabItem("📜 Histórico"):
            with gr.Row():
                history_clear = gr.Button("🗑️ Limpar Histórico")
                history_export = gr.Button("💾 Exportar JSON")
            
            history_output = gr.Textbox(
                label="Histórico Exportado",
                lines=20,
                interactive=False
            )
        
        # Tab 5: Configurações
        with gr.TabItem("⚙️ Configurações"):
            gr.Markdown(
                """
                ### Configurações do Sistema
                
                **API Key Status:**
                """
            )
            
            api_status = gr.Textbox(
                label="Status da API",
                value="✅ Configurada" if os.getenv("ANTHROPIC_API_KEY") else "❌ Não configurada",
                interactive=False
            )
            
            gr.Markdown(
                """
                **Como configurar:**
                
                1. Exporte sua API key:
                ```bash
                export ANTHROPIC_API_KEY='sua-chave-aqui'
                ```
                
                2. Instale o Claude CLI:
                ```bash
                npm install -g @anthropic-ai/claude-code
                ```
                
                3. Configure o Claude:
                ```bash
                claude config set apiKey YOUR_API_KEY
                ```
                
                **Modelo atual:** claude-3-5-sonnet-20241022
                
                **Versão do SDK:** 2.0.0
                """
            )
    
    # Event handlers
    chat_submit.click(
        fn=ask_claude_async,
        inputs=[chat_prompt, chat_system, chat_turns, chat_temp, chat_stream],
        outputs=chat_output,
        queue=True
    )
    
    chat_clear.click(
        fn=lambda: ("", ""),
        outputs=[chat_prompt, chat_output]
    )
    
    code_submit.click(
        fn=analyze_code_async,
        inputs=[code_input, code_lang, code_analysis],
        outputs=code_output,
        queue=True
    )
    
    a2a_submit.click(
        fn=execute_a2a_async,
        inputs=[a2a_task, a2a_agents, a2a_topology, a2a_turns],
        outputs=a2a_output,
        queue=True
    )
    
    history_clear.click(
        fn=clear_history,
        outputs=history_output
    )
    
    history_export.click(
        fn=export_history,
        outputs=history_output
    )

# Executar
if __name__ == "__main__":
    print("🚀 Iniciando Claude Code SDK UI...")
    print("📍 Acesse: http://localhost:7860")
    
    if not os.getenv("ANTHROPIC_API_KEY"):
        print("⚠️ AVISO: ANTHROPIC_API_KEY não configurada!")
        print("Configure com: export ANTHROPIC_API_KEY='sua-chave-aqui'")
    
    demo.queue().launch(
        server_name="0.0.0.0",
        server_port=7860,
        share=False,
        show_api=True
    )