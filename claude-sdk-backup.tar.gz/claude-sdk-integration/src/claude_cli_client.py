"""
Cliente para usar Claude Code CLI diretamente (sem API key)
O Claude Code CLI usa a autenticação já configurada localmente
"""

import subprocess
import json
import asyncio
import logging
from typing import Optional, Dict, Any, AsyncGenerator
from dataclasses import dataclass
import tempfile
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class ClaudeResponse:
    """Resposta do Claude CLI"""
    content: str
    success: bool
    error: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class ClaudeCLIClient:
    """
    Cliente que usa o Claude Code CLI diretamente
    Não precisa de API key pois usa a autenticação local do CLI
    """
    
    def __init__(self):
        """Inicializa o cliente CLI"""
        self.claude_command = "claude"  # ou caminho completo se necessário
        self._verify_cli()
    
    def _verify_cli(self):
        """Verifica se o Claude CLI está instalado e configurado"""
        try:
            result = subprocess.run(
                [self.claude_command, "--version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0:
                logger.info(f"✅ Claude CLI encontrado: {result.stdout.strip()}")
            else:
                raise RuntimeError(f"Claude CLI com erro: {result.stderr}")
        except FileNotFoundError:
            raise RuntimeError(
                "Claude CLI não encontrado. Instale com: npm install -g @anthropic-ai/claude-code"
            )
        except Exception as e:
            raise RuntimeError(f"Erro ao verificar Claude CLI: {str(e)}")
    
    async def query_simple(self, prompt: str, context: Optional[str] = None) -> ClaudeResponse:
        """
        Executa query usando o Claude CLI
        
        Args:
            prompt: Pergunta/comando para o Claude
            context: Contexto adicional (arquivo, código, etc)
            
        Returns:
            ClaudeResponse com a resposta
        """
        try:
            full_prompt = prompt
            if context:
                full_prompt = f"{context}\n\n{prompt}"
            
            logger.info(f"🤖 Executando via CLI: {prompt[:100]}...")
            
            # Executar comando Claude
            cmd = [self.claude_command, "-p", full_prompt]
            
            # Adicionar flags úteis
            cmd.extend([
                "--no-cache",  # Não usar cache
                "--json",      # Saída em JSON se disponível
            ])
            
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            stdout, stderr = await process.communicate()
            
            if process.returncode == 0:
                response_text = stdout.decode('utf-8')
                
                # Tentar parsear como JSON
                try:
                    response_data = json.loads(response_text)
                    content = response_data.get('content', response_text)
                    metadata = response_data.get('metadata', {})
                except json.JSONDecodeError:
                    # Se não for JSON, usar como texto puro
                    content = response_text
                    metadata = {}
                
                return ClaudeResponse(
                    content=content,
                    success=True,
                    metadata=metadata
                )
            else:
                error_msg = stderr.decode('utf-8') or "Erro desconhecido"
                logger.error(f"❌ Erro do CLI: {error_msg}")
                return ClaudeResponse(
                    content="",
                    success=False,
                    error=error_msg
                )
                
        except Exception as e:
            logger.error(f"❌ Erro ao executar CLI: {str(e)}")
            return ClaudeResponse(
                content="",
                success=False,
                error=str(e)
            )
    
    async def analyze_code(
        self, 
        code: str, 
        language: str = "python",
        task: str = "analyze"
    ) -> ClaudeResponse:
        """
        Analisa código usando Claude CLI
        
        Args:
            code: Código para analisar
            language: Linguagem do código
            task: Tipo de análise
            
        Returns:
            ClaudeResponse com análise
        """
        prompts = {
            "analyze": f"Analise este código {language} e identifique melhorias:\n```{language}\n{code}\n```",
            "review": f"Revise este código {language} detalhadamente:\n```{language}\n{code}\n```",
            "optimize": f"Otimize este código {language}:\n```{language}\n{code}\n```",
            "explain": f"Explique este código {language}:\n```{language}\n{code}\n```"
        }
        
        prompt = prompts.get(task, prompts["analyze"])
        return await self.query_simple(prompt)
    
    async def generate_code(
        self,
        description: str,
        language: str = "python",
        framework: Optional[str] = None
    ) -> ClaudeResponse:
        """
        Gera código usando Claude CLI
        
        Args:
            description: Descrição do código a gerar
            language: Linguagem alvo
            framework: Framework específico
            
        Returns:
            ClaudeResponse com código gerado
        """
        prompt = f"Gere código {language}"
        if framework:
            prompt += f" usando {framework}"
        prompt += f" para: {description}\n\nRetorne apenas o código."
        
        return await self.query_simple(prompt)
    
    async def execute_with_file(self, file_path: str, instruction: str) -> ClaudeResponse:
        """
        Executa comando Claude com um arquivo como contexto
        
        Args:
            file_path: Caminho do arquivo
            instruction: Instrução sobre o que fazer com o arquivo
            
        Returns:
            ClaudeResponse com resultado
        """
        try:
            # Ler arquivo
            with open(file_path, 'r') as f:
                content = f.read()
            
            # Executar com contexto do arquivo
            prompt = f"Arquivo: {file_path}\n\n{instruction}"
            return await self.query_simple(prompt, context=content)
            
        except Exception as e:
            logger.error(f"❌ Erro ao ler arquivo: {str(e)}")
            return ClaudeResponse(
                content="",
                success=False,
                error=str(e)
            )
    
    async def stream_response(
        self,
        prompt: str,
        callback: Optional[callable] = None
    ) -> AsyncGenerator[str, None]:
        """
        Stream de resposta do Claude CLI
        
        Args:
            prompt: Prompt para o Claude
            callback: Função callback para cada linha
            
        Yields:
            Linhas de texto da resposta
        """
        try:
            cmd = [self.claude_command, "-p", prompt, "--stream"]
            
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            # Stream linha por linha
            while True:
                line = await process.stdout.readline()
                if not line:
                    break
                
                text = line.decode('utf-8').rstrip()
                if text:
                    if callback:
                        await callback(text)
                    yield text
            
            # Aguardar processo terminar
            await process.wait()
            
        except Exception as e:
            logger.error(f"❌ Erro no streaming: {str(e)}")
            yield f"Erro: {str(e)}"
    
    async def execute_with_a2a(
        self,
        task: str,
        agents: Optional[list] = None
    ) -> ClaudeResponse:
        """
        Executa tarefa simulando coordenação A2A
        
        Args:
            task: Tarefa para executar
            agents: Lista de "agentes" (papéis) para simular
            
        Returns:
            ClaudeResponse com resultado
        """
        agents = agents or ["developer", "reviewer", "tester"]
        agents_str = ", ".join(agents)
        
        prompt = f"""
        Execute esta tarefa usando uma abordagem multi-perspectiva.
        
        Tarefa: {task}
        
        Analise a tarefa sob as perspectivas de: {agents_str}
        
        Para cada perspectiva:
        1. Analise os requisitos
        2. Proponha uma solução
        3. Identifique possíveis problemas
        
        Depois, integre todas as perspectivas em uma solução final completa.
        """
        
        return await self.query_simple(prompt)
    
    async def test_connection(self) -> bool:
        """
        Testa se o CLI está funcionando
        
        Returns:
            True se funcionando
        """
        try:
            response = await self.query_simple("Responda apenas: OK")
            return response.success and "OK" in response.content.upper()
        except Exception as e:
            logger.error(f"❌ Falha no teste: {str(e)}")
            return False


# Funções helper para uso direto
async def quick_query(prompt: str) -> str:
    """Query rápida via CLI"""
    client = ClaudeCLIClient()
    response = await client.query_simple(prompt)
    return response.content if response.success else f"Erro: {response.error}"


async def analyze_file_cli(file_path: str) -> str:
    """Analisa arquivo via CLI"""
    client = ClaudeCLIClient()
    
    with open(file_path, 'r') as f:
        code = f.read()
    
    language = file_path.split('.')[-1]
    response = await client.analyze_code(code, language)
    return response.content if response.success else f"Erro: {response.error}"


# Exemplo de uso
if __name__ == "__main__":
    async def main():
        print("🧪 Testando Claude CLI Client (sem API key)")
        print("-" * 50)
        
        client = ClaudeCLIClient()
        
        # Teste 1: Conexão
        print("\n1️⃣ Testando conexão...")
        connected = await client.test_connection()
        print(f"   Conectado: {'✅ Sim' if connected else '❌ Não'}")
        
        if not connected:
            print("\n❌ Claude CLI não está funcionando corretamente")
            print("Verifique se está instalado e configurado:")
            print("  1. npm install -g @anthropic-ai/claude-code")
            print("  2. claude login")
            return
        
        # Teste 2: Query simples
        print("\n2️⃣ Query simples...")
        response = await client.query_simple("O que é Python em uma linha?")
        if response.success:
            print(f"   Resposta: {response.content[:100]}...")
        else:
            print(f"   Erro: {response.error}")
        
        # Teste 3: Gerar código
        print("\n3️⃣ Gerando código...")
        response = await client.generate_code(
            "função para validar email",
            language="python"
        )
        if response.success:
            print(f"   Código gerado:")
            print(response.content[:300] + "..." if len(response.content) > 300 else response.content)
        
        # Teste 4: Streaming
        print("\n4️⃣ Testando streaming...")
        print("   Resposta: ", end="")
        async for line in client.stream_response("Conte de 1 a 3"):
            print(line, end=" ")
        print()
        
        # Teste 5: A2A simulado
        print("\n5️⃣ Simulando A2A...")
        response = await client.execute_with_a2a(
            "criar uma função de soma",
            agents=["coder", "tester"]
        )
        if response.success:
            print(f"   Resultado A2A: {response.content[:200]}...")
        
        print("\n" + "-" * 50)
        print("✅ Todos os testes concluídos!")
    
    asyncio.run(main())