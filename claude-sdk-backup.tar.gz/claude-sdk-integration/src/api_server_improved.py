# api_server_improved.py
import os
import time
import json
import logging
from typing import AsyncGenerator, Optional, Dict, Any
from datetime import datetime

from fastapi import FastAPI, HTTPException, Header, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, Response
from pydantic import BaseModel, Field

# Claude Code SDK (agente de código/CLI), não confundir com o SDK "anthropic"
try:
    from claude_code_sdk import (
        query,
        ClaudeCodeOptions,
        AssistantMessage,
        ResultMessage,
        TextBlock,
        CLINotFoundError,
        ProcessError,
        CLIJSONDecodeError,
    )
except ImportError:
    print("⚠️ Claude Code SDK não instalado. Instalando...")
    import subprocess
    subprocess.run(["pip", "install", "claude-code-sdk"], check=True)
    from claude_code_sdk import (
        query,
        ClaudeCodeOptions,
        AssistantMessage,
        ResultMessage,
        TextBlock,
        CLINotFoundError,
        ProcessError,
        CLIJSONDecodeError,
    )

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

APP_NAME = "claude-sdk-integration"
API_KEY_ENV = "API_SERVER_KEY"          # sua key para proteger o endpoint (opcional)
CLAUDE_API_ENV = "ANTHROPIC_API_KEY"    # obrigatória para o Claude Code CLI

app = FastAPI(
    title=f"{APP_NAME} API",
    version="2.0.0",
    description="API REST para integração do Claude Code SDK com UI"
)

# CORS (ajuste para o seu ambiente)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Em produção, liste domínios específicos
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# --------- Models ---------
class PromptRequest(BaseModel):
    """Requisição para o Claude Code"""
    prompt: str = Field(..., description="Texto do prompt para o Claude Code")
    max_turns: int = Field(2, ge=1, le=8, description="Limite de turnos no agente de código")
    system_prompt: Optional[str] = Field(None, description="System prompt opcional")
    include_metadata: bool = Field(True, description="Retorna metadados (custo, duração, etc.)")
    temperature: Optional[float] = Field(0.7, ge=0, le=1, description="Temperatura para geração")
    max_tokens: Optional[int] = Field(4096, description="Máximo de tokens na resposta")
    # Futuras opções do Claude Code:
    tools: Optional[list[str]] = Field(None, description="Ferramentas habilitadas")
    files: Optional[list[str]] = Field(None, description="Arquivos para contexto")


class AskResponse(BaseModel):
    """Resposta da API"""
    result: str
    cost: Optional[float] = None
    duration_ms: Optional[int] = None
    num_turns: Optional[int] = None
    session_id: Optional[str] = None
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())


class A2ARequest(BaseModel):
    """Requisição para integração A2A"""
    task: str = Field(..., description="Tarefa para executar com A2A")
    agents: list[str] = Field(
        default=["coder", "reviewer", "tester"],
        description="Agentes A2A para usar"
    )
    topology: str = Field("hierarchical", description="Topologia do swarm")
    max_turns: int = Field(3, ge=1, le=10)


class CodeAnalysisRequest(BaseModel):
    """Requisição para análise de código"""
    code: str = Field(..., description="Código para analisar")
    language: str = Field("python", description="Linguagem do código")
    analysis_type: str = Field(
        "review",
        description="Tipo: review, optimize, explain, security, performance"
    )


# --------- Auth (opcional) ---------
def require_api_key(x_api_key: Optional[str] = Header(default=None)) -> None:
    """Validação de API key via header"""
    expected = os.getenv(API_KEY_ENV)
    if expected:  # só exige se configurado
        if not x_api_key or x_api_key != expected:
            logger.warning(f"Tentativa de acesso não autorizado com key: {x_api_key}")
            raise HTTPException(status_code=401, detail="Unauthorized")


# --------- Middleware de Logging ---------
@app.middleware("http")
async def log_requests(request, call_next):
    """Log de todas as requisições"""
    start_time = time.time()
    
    # Log da requisição
    logger.info(f"📥 {request.method} {request.url.path}")
    
    # Processar requisição
    response = await call_next(request)
    
    # Log da resposta
    process_time = (time.time() - start_time) * 1000
    logger.info(f"📤 {request.url.path} - Status: {response.status_code} - Tempo: {process_time:.2f}ms")
    
    # Adicionar header com tempo de processamento
    response.headers["X-Process-Time"] = str(process_time)
    
    return response


# --------- Health & Info ---------
@app.get("/")
async def root():
    """Informações da API"""
    return {
        "name": APP_NAME,
        "version": app.version,
        "status": "online",
        "endpoints": {
            "health": "/health",
            "ask": "/ask",
            "stream": "/ask/stream",
            "sse": "/ask/sse",
            "a2a": "/a2a",
            "analyze": "/analyze",
            "docs": "/docs"
        }
    }


@app.get("/health")
async def health() -> Dict[str, Any]:
    """Health check endpoint"""
    has_key = bool(os.getenv(CLAUDE_API_ENV))
    
    # Tentar verificar se CLI está instalado
    cli_installed = False
    try:
        import subprocess
        result = subprocess.run(
            ["claude", "--version"],
            capture_output=True,
            text=True,
            timeout=2
        )
        cli_installed = result.returncode == 0
    except:
        pass
    
    return {
        "ok": has_key and cli_installed,
        "has_anthropic_key": has_key,
        "cli_installed": cli_installed,
        "service": APP_NAME,
        "version": app.version,
        "timestamp": datetime.now().isoformat()
    }


# --------- Core (Respostas completas) ---------
@app.post("/ask", response_model=AskResponse, dependencies=[Depends(require_api_key)])
async def ask_claude(req: PromptRequest) -> AskResponse:
    """
    Coleta a resposta completa do stream e retorna em JSON (com metadados opcionais).
    """
    # Validação
    if not os.getenv(CLAUDE_API_ENV):
        logger.error("ANTHROPIC_API_KEY não configurada")
        raise HTTPException(
            status_code=500,
            detail=f"Faltando variável de ambiente {CLAUDE_API_ENV}.",
        )

    start_time = time.time()
    
    options = ClaudeCodeOptions(
        max_turns=req.max_turns,
        system_prompt=req.system_prompt,
        temperature=req.temperature,
        max_tokens=req.max_tokens,
        tools=req.tools,
        files=req.files,
    )

    text_chunks: list[str] = []
    meta: Dict[str, Any] = {}

    try:
        logger.info(f"🤖 Processando prompt: {req.prompt[:100]}...")
        
        async for msg in query(prompt=req.prompt, options=options):
            if isinstance(msg, AssistantMessage):
                for block in msg.content:
                    if isinstance(block, TextBlock) and block.text:
                        text_chunks.append(block.text)
            elif isinstance(msg, ResultMessage):
                if req.include_metadata:
                    meta = {
                        "cost": getattr(msg, "total_cost_usd", None),
                        "duration_ms": int((time.time() - start_time) * 1000),
                        "num_turns": getattr(msg, "num_turns", None),
                        "session_id": getattr(msg, "session_id", None),
                    }
        
        result = "".join(text_chunks)
        logger.info(f"✅ Resposta gerada: {len(result)} caracteres")
        
        return AskResponse(result=result, **meta)
        
    except CLINotFoundError:
        logger.error("Claude Code CLI não encontrado")
        raise HTTPException(
            status_code=500,
            detail="Claude Code CLI não encontrado. Instale com: npm i -g @anthropic-ai/claude-code",
        )
    except CLIJSONDecodeError as e:
        logger.error(f"Erro ao decodificar JSON do CLI: {e}")
        raise HTTPException(status_code=502, detail="Falha ao interpretar a saída do CLI.")
    except ProcessError as e:
        logger.error(f"Processo do CLI falhou: {e}")
        raise HTTPException(status_code=502, detail=f"Processo do CLI falhou (exit {e.exit_code}).")
    except Exception as e:
        logger.error(f"Erro inesperado: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# --------- Streaming (Text) ---------
@app.post("/ask/stream", dependencies=[Depends(require_api_key)])
async def ask_claude_stream(req: PromptRequest):
    """
    Stream de texto bruto (chunked). Ideal para UIs com atualização em tempo real.
    """
    if not os.getenv(CLAUDE_API_ENV):
        raise HTTPException(
            status_code=500,
            detail=f"Faltando variável de ambiente {CLAUDE_API_ENV}.",
        )

    options = ClaudeCodeOptions(
        max_turns=req.max_turns,
        system_prompt=req.system_prompt,
        temperature=req.temperature,
        max_tokens=req.max_tokens,
    )

    async def generator() -> AsyncGenerator[bytes, None]:
        start_time = time.time()
        try:
            logger.info(f"🔄 Iniciando stream para: {req.prompt[:100]}...")
            
            async for msg in query(prompt=req.prompt, options=options):
                if isinstance(msg, AssistantMessage):
                    for block in msg.content:
                        if isinstance(block, TextBlock) and block.text:
                            # envia o texto conforme chega
                            yield block.text.encode("utf-8")
                elif isinstance(msg, ResultMessage):
                    # Opcional: envie metadados ao final
                    if req.include_metadata:
                        duration = int((time.time() - start_time) * 1000)
                        trailer = {
                            "cost": getattr(msg, "total_cost_usd", None),
                            "duration_ms": duration,
                            "num_turns": getattr(msg, "num_turns", None),
                            "session_id": getattr(msg, "session_id", None),
                        }
                        yield f'\n\n[METADATA]{json.dumps(trailer)}'.encode("utf-8")
                        
        except CLINotFoundError:
            yield b"\n\n[ERROR] Claude Code CLI nao encontrado. Instale com: npm i -g @anthropic-ai/claude-code"
        except CLIJSONDecodeError:
            yield b"\n\n[ERROR] Falha ao interpretar a saida do CLI."
        except ProcessError as e:
            yield f"\n\n[ERROR] Processo do CLI falhou (exit {e.exit_code}).".encode("utf-8")
        except Exception as e:
            yield f"\n\n[ERROR] {str(e)}".encode("utf-8")

    return StreamingResponse(generator(), media_type="text/plain; charset=utf-8")


# --------- SSE (Server-Sent Events) ---------
@app.post("/ask/sse", dependencies=[Depends(require_api_key)])
async def ask_claude_sse(req: PromptRequest):
    """
    Stream usando Server-Sent Events (SSE) para melhor compatibilidade com browsers.
    """
    if not os.getenv(CLAUDE_API_ENV):
        raise HTTPException(
            status_code=500,
            detail=f"Faltando variável de ambiente {CLAUDE_API_ENV}.",
        )

    options = ClaudeCodeOptions(
        max_turns=req.max_turns,
        system_prompt=req.system_prompt,
        temperature=req.temperature,
        max_tokens=req.max_tokens,
    )

    async def sse_generator() -> AsyncGenerator[bytes, None]:
        start_time = time.time()
        try:
            # Enviar evento inicial
            yield f"data: {json.dumps({'type': 'start', 'timestamp': datetime.now().isoformat()})}\n\n".encode()
            
            async for msg in query(prompt=req.prompt, options=options):
                if isinstance(msg, AssistantMessage):
                    for block in msg.content:
                        if isinstance(block, TextBlock) and block.text:
                            # Enviar chunk como evento SSE
                            event = {
                                "type": "chunk",
                                "content": block.text
                            }
                            yield f"data: {json.dumps(event)}\n\n".encode()
                            
                elif isinstance(msg, ResultMessage):
                    # Enviar metadados finais
                    if req.include_metadata:
                        duration = int((time.time() - start_time) * 1000)
                        event = {
                            "type": "metadata",
                            "cost": getattr(msg, "total_cost_usd", None),
                            "duration_ms": duration,
                            "num_turns": getattr(msg, "num_turns", None),
                            "session_id": getattr(msg, "session_id", None),
                        }
                        yield f"data: {json.dumps(event)}\n\n".encode()
            
            # Evento de conclusão
            yield f"data: {json.dumps({'type': 'done'})}\n\n".encode()
            
        except Exception as e:
            # Enviar erro como evento
            error_event = {
                "type": "error",
                "message": str(e)
            }
            yield f"data: {json.dumps(error_event)}\n\n".encode()

    return StreamingResponse(
        sse_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"  # Para Nginx
        }
    )


# --------- A2A Integration ---------
@app.post("/a2a", response_model=AskResponse, dependencies=[Depends(require_api_key)])
async def execute_a2a(req: A2ARequest) -> AskResponse:
    """
    Executa tarefa usando agentes A2A através do Claude Code.
    """
    if not os.getenv(CLAUDE_API_ENV):
        raise HTTPException(
            status_code=500,
            detail=f"Faltando variável de ambiente {CLAUDE_API_ENV}.",
        )
    
    # Construir prompt para A2A
    agent_list = ", ".join(req.agents)
    prompt = f"""
    Execute esta tarefa usando uma abordagem multi-agente A2A:
    
    Tarefa: {req.task}
    
    Use os seguintes agentes especializados: {agent_list}
    
    Topologia do swarm: {req.topology}
    
    Coordene os agentes para:
    1. Analisar os requisitos da tarefa
    2. Distribuir responsabilidades entre os agentes
    3. Executar as subtarefas em paralelo quando possível
    4. Integrar os resultados
    5. Retornar a solução completa
    
    Seja conciso e focado no resultado final.
    """
    
    # Criar request para o Claude
    claude_req = PromptRequest(
        prompt=prompt,
        max_turns=req.max_turns,
        system_prompt="Você é um coordenador de agentes A2A especializado em desenvolvimento de software.",
        include_metadata=True
    )
    
    # Executar através do endpoint ask
    return await ask_claude(claude_req)


# --------- Code Analysis ---------
@app.post("/analyze", response_model=AskResponse, dependencies=[Depends(require_api_key)])
async def analyze_code(req: CodeAnalysisRequest) -> AskResponse:
    """
    Analisa código usando Claude Code com diferentes tipos de análise.
    """
    if not os.getenv(CLAUDE_API_ENV):
        raise HTTPException(
            status_code=500,
            detail=f"Faltando variável de ambiente {CLAUDE_API_ENV}.",
        )
    
    # Prompts específicos por tipo de análise
    analysis_prompts = {
        "review": f"Faça uma revisão completa deste código {req.language}, identificando bugs, problemas de segurança, e sugestões de melhoria:\n\n```{req.language}\n{req.code}\n```",
        "optimize": f"Otimize este código {req.language} para melhor performance e legibilidade:\n\n```{req.language}\n{req.code}\n```",
        "explain": f"Explique detalhadamente o que este código {req.language} faz, linha por linha:\n\n```{req.language}\n{req.code}\n```",
        "security": f"Analise este código {req.language} focando em vulnerabilidades de segurança:\n\n```{req.language}\n{req.code}\n```",
        "performance": f"Analise a performance deste código {req.language} e sugira otimizações:\n\n```{req.language}\n{req.code}\n```"
    }
    
    prompt = analysis_prompts.get(
        req.analysis_type,
        analysis_prompts["review"]
    )
    
    # Criar request para o Claude
    claude_req = PromptRequest(
        prompt=prompt,
        max_turns=2,
        system_prompt=f"Você é um especialista em {req.language} com foco em code review e boas práticas.",
        include_metadata=True
    )
    
    # Executar análise
    return await ask_claude(claude_req)


# --------- Execução ---------
if __name__ == "__main__":
    import uvicorn
    
    # Verificar configuração
    if not os.getenv(CLAUDE_API_ENV):
        print("⚠️ AVISO: ANTHROPIC_API_KEY não configurada!")
        print("Configure com: export ANTHROPIC_API_KEY='sua-chave-aqui'")
    
    if os.getenv(API_KEY_ENV):
        print(f"🔒 API protegida com chave. Use header: X-API-Key: {os.getenv(API_KEY_ENV)}")
    else:
        print("🔓 API sem autenticação (configure API_SERVER_KEY para habilitar)")
    
    print(f"\n🚀 Iniciando {APP_NAME} API v{app.version}")
    print("📚 Documentação disponível em: http://localhost:8000/docs")
    print("🔗 Endpoints principais:")
    print("   - POST /ask - Resposta completa")
    print("   - POST /ask/stream - Streaming de texto")
    print("   - POST /ask/sse - Server-Sent Events")
    print("   - POST /a2a - Integração com agentes A2A")
    print("   - POST /analyze - Análise de código")
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )