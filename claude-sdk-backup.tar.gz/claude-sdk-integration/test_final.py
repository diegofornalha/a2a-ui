#!/usr/bin/env python3
"""
Teste final da integração Claude Code sem API Key
"""

import subprocess
import sys
import os
import asyncio
from pathlib import Path

# Adicionar src ao path
sys.path.insert(0, str(Path(__file__).parent / "src"))


def check_claude_cli():
    """Verifica se Claude CLI está instalado"""
    print("\n🔍 Verificando Claude CLI...")
    try:
        result = subprocess.run(
            ["claude", "--version"],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode == 0:
            print(f"✅ Claude CLI instalado: {result.stdout.strip()}")
            return True
        else:
            print(f"❌ Claude CLI com erro: {result.stderr}")
            return False
    except FileNotFoundError:
        print("❌ Claude CLI não encontrado")
        print("\n📦 Para instalar:")
        print("   npm install -g @anthropic-ai/claude-code")
        return False
    except Exception as e:
        print(f"❌ Erro: {str(e)}")
        return False


def test_claude_direct():
    """Testa Claude diretamente no terminal"""
    print("\n🧪 Testando Claude diretamente...")
    try:
        # Teste simples
        result = subprocess.run(
            ["claude", "-p", "Responda apenas: OK"],
            capture_output=True,
            text=True,
            timeout=10
        )
        
        if result.returncode == 0 and "OK" in result.stdout.upper():
            print("✅ Claude respondendo corretamente via terminal")
            print(f"   Resposta: {result.stdout[:100]}")
            return True
        else:
            print("❌ Claude não respondeu como esperado")
            if result.stderr:
                print(f"   Erro: {result.stderr}")
            print("\n🔑 Você precisa fazer login:")
            print("   claude login")
            return False
    except Exception as e:
        print(f"❌ Erro ao testar: {str(e)}")
        return False


async def test_python_client():
    """Testa o cliente Python"""
    print("\n🐍 Testando cliente Python...")
    try:
        from claude_cli_client_fixed import ClaudeCLIClient
        
        client = ClaudeCLIClient()
        print("✅ Cliente Python inicializado")
        
        # Teste de conexão
        connected = await client.test_connection()
        if connected:
            print("✅ Cliente Python funcionando")
            
            # Teste de query
            response = await client.query_simple("Diga 'teste ok'")
            if response.success:
                print(f"✅ Query funcionando: {response.content[:50]}...")
                return True
            else:
                print(f"❌ Query falhou: {response.error}")
                return False
        else:
            print("❌ Cliente não conectado")
            return False
            
    except ImportError as e:
        print(f"❌ Erro de importação: {str(e)}")
        print("\n📦 Instale as dependências:")
        print("   pip install fastapi uvicorn aiohttp")
        return False
    except Exception as e:
        print(f"❌ Erro: {str(e)}")
        return False


def test_api_server():
    """Testa se o servidor API pode ser iniciado"""
    print("\n🌐 Verificando servidor API...")
    try:
        # Tentar importar
        from api_server_cli import app
        print("✅ Servidor API pode ser importado")
        
        # Verificar dependências
        import fastapi
        import uvicorn
        print("✅ Dependências FastAPI instaladas")
        
        return True
    except ImportError as e:
        print(f"❌ Falta dependência: {str(e)}")
        print("\n📦 Instale:")
        print("   pip install fastapi uvicorn")
        return False


def test_ui():
    """Verifica se a UI pode ser iniciada"""
    print("\n🎨 Verificando UI...")
    try:
        import gradio
        print("✅ Gradio instalado")
        
        # Verificar se UI pode ser importada
        from ui_complete import demo
        print("✅ UI pode ser importada")
        
        return True
    except ImportError as e:
        print(f"❌ Falta dependência: {str(e)}")
        print("\n📦 Instale:")
        print("   pip install gradio")
        return False


async def main():
    """Executa todos os testes"""
    print("\n" + "="*60)
    print("🧪 TESTE FINAL - CLAUDE CODE SEM API KEY")
    print("="*60)
    
    results = {
        "CLI Instalado": check_claude_cli(),
        "CLI Funcionando": False,
        "Cliente Python": False,
        "Servidor API": test_api_server(),
        "Interface UI": test_ui()
    }
    
    # Só testa funcionamento se CLI instalado
    if results["CLI Instalado"]:
        results["CLI Funcionando"] = test_claude_direct()
        
        # Só testa cliente Python se CLI funcionando
        if results["CLI Funcionando"]:
            results["Cliente Python"] = await test_python_client()
    
    # Resumo
    print("\n" + "="*60)
    print("📊 RESUMO DOS TESTES")
    print("="*60)
    
    for teste, resultado in results.items():
        status = "✅" if resultado else "❌"
        print(f"  {status} {teste}")
    
    todos_ok = all(results.values())
    parcial_ok = sum(results.values()) >= 3
    
    print("\n" + "="*60)
    
    if todos_ok:
        print("🎉 SUCESSO TOTAL!")
        print("\n✅ Sistema completamente funcional!")
        print("\n🚀 Para começar a usar:")
        print("   1. Interface Gráfica: python ui_complete.py")
        print("   2. API Server: python src/api_server_cli.py")
        print("   3. Modo Interativo: python run_without_api_key.py")
        
    elif parcial_ok:
        print("⚠️ SISTEMA PARCIALMENTE FUNCIONAL")
        print("\nResolva os problemas acima para funcionalidade completa.")
        
        if not results["CLI Funcionando"]:
            print("\n🔑 Faça login no Claude:")
            print("   claude login")
            
    else:
        print("❌ SISTEMA NÃO FUNCIONAL")
        print("\n📋 Passos para configurar:")
        print("1. Instale o Claude CLI:")
        print("   npm install -g @anthropic-ai/claude-code")
        print("\n2. Faça login:")
        print("   claude login")
        print("\n3. Instale dependências Python:")
        print("   pip install fastapi uvicorn gradio aiohttp")
        print("\n4. Execute este teste novamente:")
        print("   python test_final.py")
    
    return todos_ok


if __name__ == "__main__":
    success = asyncio.run(main())
    sys.exit(0 if success else 1)